var widgetconfig = {
    "background_picture": "9g4n4pb.58e6374_f342163_cSd_cb",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "4000",
        "Height": "5000",
        "X": "-61",
        "Y": "-91"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>t\u201cpBmeei:negp ydte-shipraorugsa r awpe-ltlq--b\u0022e=ienlgy tosf  pt<h e> pn/a<t.ilvlee wp ospau leastuiaolncs \u201ds<i/hstp afno>  d<npe  sethytl et=a\u0022  gmnairegbi-nl-lteowp :r0ipexh;t  mdanrag isne-vbiottatno me:h0tp xf;o  mnaorigtianr-eldeifstn:o0cp xn;i  meadragmi ne-rruitgshetg: 0npexk;o t- qat -sbil oecrke-hiTn d.etncti:l0f;n otce xttn-eilnodievn tr:o0 pdxe;m\u0022r>aH eorten it hree vcor ugxn iolfi otbh e) >Bnearplsi/n< aCcoinrffeAr ernocfe  eilsb mlaaricdS  beahrte> \u0022f;o0r0 6a:ltlh gtioe ws-eten.o fT h\u0022e= ecloyntfse rneanpcse< (h asde ibreoetni rprreotm pntaecdi rbfyA  trhoef  snuodidteint eepmmeorcg egnnciet noefv ear pn efwol yy auwn iaf isead  dGeemramrafn ys ia st xae tp lsaiyheTr  .oeng atthse  ciinttseirlnaaitrieopnmail ,",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "19",
            "X": "-08",
            "Y": "398"
        },
        "point": {
            "x": "-7",
            "y": "398"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tAprmtei:celpey t1-<h/psapragna>r a<pp- tsqt-y\u0022l=ee=l\u0022y tmsa rpg<i n>-pt/o<p.:e0rpaxb;  dmiaarlg ienr-ab omtstiolma:i0rpexp;m im anrageipno-rlueEf tf:o0 psxn;o imtaarvgiitno-mr icgihmto:n0opcxe;  e-hqTt -.bnlioscakB- iongdneonCt :e0h;t  tteuxoth-giunodrehntt :\u20130 psxe;t\u0022a>tTSh idse tairntUi celhet  gdunaar asnntoeietsa nt hnea efproereu Et r3a1d ee hotf  \u2013a lslr e1w4o ps iygrnoat",
        "marker-type": "llaeb",
        "position": {
            "Width": "130",
            "Height": "14",
            "X": "-28",
            "Y": "570"
        },
        "point": {
            "x": "-9",
            "y": "580"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tAprmtei:celpey t6-<h/psapragna>r a<pp- tsqt-y\u0022l=ee=l\u0022y tmsa rpg<i n>-pt/o<p.:e0cpnxa;t pmeacrcgai nc-iblobtutpo mn:i0apgx ;t cmaa reghitn -dleepflte:h0 prxa;l umcairtgrianp- rniig hetl:c0iptxr;a  -sqith-Tb l.opcikh-sirnodwe nfto: 0m;o dteeexrtf- idnndae nnto:i0tpaxr;e\u0022l>oTth issu oairgtiilcelre  foof  etehten aArcatu gi se hfto csuaswe ds iohnt  perdeissegnntoilnag  ,tshpea harlelpe g,eydl ghnuimsainriptraurSi a.ns naosipsescitms  loafc itlheeg nEauvreo pseuaone tshcgriarm brliee hfto rn iA fmreihcta nt stiesrsrai tootr isenso.i tMcoestto rnpo tlaabilcye,p st hneervei gi se ba  dclaulolw  hseerier oftoirr rtehte  nEaucriorpfeAa ne speohwte rdse ttios ievn souhrwe  stehier apnroeissesrivma tniaoint soifr htCh et anhatt isvees ipseaohpplmees .o sTlhai se siunacllcu dseidh,T  s.idgenrieftincuaonctnley ,y ethhte  tsauhptp ryersesviaolns  olfl aa ndyn a",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "17",
            "X": "-77",
            "Y": "625"
        },
        "point": {
            "x": "-2",
            "y": "606"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tCphmaep:teepry tV-Ih<p/asrpgaanr>a p<-pt qs-t\u0022y=leel=y\u0022t sm apr<g i>np-/t<o.ps:r0epwxo;p  mlaarigrienp-mbio tntaoemp:o0rpuxE;  nmeaerwgtienb- lsenfoti:s0npext;  emlabrigsisno-pr iggnhitc:u0dpexr;  f-oq tm-rbolfo crke-hitnodnean ts:a0w;  ttie x,te-sinnedse nsti:h0tp xn;I\u0022 >.Tsheiisr oitsi rtrheet  praireth to ff ot hsen oAictta ttihmaitl  iesh tk ngonwinn iamsr ettheed  Pnrii nlcaiiptlnee sosfe  Esfafwe cttii vteu bO c,cluoprattnioocn .e kTahti sd lsutoact eysr otthiartr etth en aEeuproorpueEa na  pwoowhe rgsn icyofuilrda lacc qnuii rten atchief irniggihst st souvje rt ocno lsoanwi asli hlTa n.dysr,o toinrlrye ti fe htth enyi  hmaedt s\u2018yesf fneocittiavret soicnciumpdaat idoenc\u2019i loofp  tah edme.h sTihlibsa tcsoeu lyde hbte  fpir ersoe n,tgendi yalsf  tsraewa tgiaelsf  wniatehp olroucEa la  lfeia d,esr",
        "marker-type": "llaeb",
        "position": {
            "Width": "94",
            "Height": "19",
            "X": "519",
            "Y": "615"
        },
        "point": {
            "x": "601",
            "y": "606"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};