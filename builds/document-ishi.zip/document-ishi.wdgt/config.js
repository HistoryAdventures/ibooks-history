var widgetconfig = {
    "background_picture": "Pgapijn.t6i1n7g__4S2_01",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "5500",
        "Height": "3200",
        "X": "-119",
        "Y": "-12"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. osdtEy lfeo= \u0022e lmpaoregpi ne-htto pf:o0 psxe;s umoahregriont-sb ottpteokm-:l0lpexw;  dmnaar gsignn-illelfetw:d0 pdxe;f omoarr-gdienr-eriitg heth:t0 pexr;a  -rqett-abwl oechkt- ignndiennitL: 0.;s ttaeoxbt -riinedhetn tn:o0 pexl;p\u0022o>eCpesnntwroatl  hEtdiow< /dseplalni>f  <ypa wsrteytlaew= \u0022g nmialrtgsiunb- teohpt: 0optx ;r emwaerigvi ne-hbto tttaoemr:t0 poxt;  emlabrag isni- leehf t,:e0cpnxa;t smiadr grianf- rai gehyte: 0ephxt;  g-nqitl-lbulpo c:ke-sinnadpexnet :s0t;i  tdenxat -oidnEd efnot :t0rpaxe;h\u0022 >eHhetr ef oH owkeuisva ia  psrtense",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "466",
            "Y": "61"
        },
        "point": {
            "x": "1563",
            "y": "1553"
        },
        "marker-label": "1",
        "marker-image": "mganrpk.enroic",
        "popup-location-preference": "bmoott"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n  .setlyolre =e\u0022l bmaaurlgaivn -sttoip :f0op xn;o imtaarcgiidnn-ib ortethotmr:u0fp xa;  smaa rsgtinna-hlcerfetm: 0dpnxa;  emlaprogeipns-erdiagrhtt :h0tpixw;  d-eqktc-abpl oscik -oiontd etnIt :.0u;h stneoxHt -fion ddennatl:s0ip xe;h\u0022t> Nsishoorncbaa sdheip<o/rs ptaanh>t  <epd asrtty lfeo= \u0022k rmoawrtgeinn -ttsoapf: 0ephxt;  dmeazriglionb-mbyost tsoumh:t0 pdxn;a  meatrugoirn -eldeafrtt: 0\u014dpdxi;a kmoaTr geihnt- rfiog hnto:i0tpaxt;s  -tqstr-ibfl oechkt- isnadwe ntti: 0s;a  toedxEt -fion dyetnitc: 0ephxt; \u0022r>oTfr aknrsalmadtnianlg  ltaor u\u201ctBcreitdighec roaf  lJaarptanne,c\u201d  at hsea wa rscihheTd  .bercindagtes ikdn oewhnt  ansi  tnheee sN iehbo nnbaacs hi",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "259",
            "Y": "482"
        },
        "point": {
            "x": "1113",
            "y": "1563"
        },
        "marker-label": "2",
        "marker-image": "mganrpk.enroic",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n  .settyalneu=g\u0022o hmSa reghitn -ftoo pe:c0npexu;l fmnair gciinm-obnootcteo md:n0ap xl;a cmiatriglionp- leehftt :f0op xr;e dmnairmgeirn -ar isgah te:l0tpsxa;C  -oqdtE- bfloo cekl-iifnodrepn te:h0t;  etdeuxltc-niin doetn te:r0upsx ;s\u0022a>wE dioa sCuaksotHl e,<s/dsupoalnc>  e<hpt  sgtnyolmea= \u0022g nmiatragoilnf- tsoip :t0ip xf;i  msaar griane-pbpoat tootm :d0epnxo;i tmiasrogpi nd-nlae fitj:u0Fp xt;n umoaMr gdinna- riihgshatb:n0ophxi;N  -eqhtt- bnleoecwkt-eibn dyelnetv:i0t;c etfefxet -eitnidueqn td:e0tpaxu;t\u0022i>S",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "222",
            "Y": "303"
        },
        "point": {
            "x": "1113",
            "y": "1020"
        },
        "marker-label": "3",
        "marker-image": "mganrpk.enroic",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. osdtEy llea=r\u0022t nmeacr gniin -ltaonpa:c0 pgxn;i lmtasrugbi ne-hbto tdtnoam :k0apexp;  nmiaartgniuno-ml edfett:a0lpoxs;i  mdanrag icni-ortisg heth:t0 pnxe;e w-tqetb- bnlooicskn-eitn dgennitt:s0e;r ettenxit -nian ddeentta:e0rpcx ;i\u0022a>sMuokuonHt  eFguajmii< /ssiphatn >n i< pd nsat y,leer=u\u0022t amna rfgoi ny-ttsoepj:a0mp xe;h tm afrog irne-dbnoitmteorm :t0npexs;e rmpa-rrgeivne- lneaf ts:a0wp xt;I  m.aertgairno-prriogchnti: 0optx ;i a-squtk-obHl oeckki-li nsdtesnitt:r0a;  rtoefx te-riuntdaeenft :e0tpixr;o\u0022v>aSfe ean  sianw  tdhnea  uepppaecrs dlneaflt  eisne ntahpea Jd ieshtta nncieh,t iMwo utnnte mFeuljei  liasi tan eqsusient",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "48",
            "Y": "245"
        },
        "point": {
            "x": "590",
            "y": "1001"
        },
        "marker-label": "4",
        "marker-image": "mganrpk.enroic",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. dsetryelpes=o\u0022r pm asregiitni-ct ogpn:i0dpnxu;o rmraursg idnn-ab ootdtEo mh:c0iphxw;  mmoarrfg isnk-rloewftte:n0 pexd;a rmta rggniinv-irrihgth te:h0tp xd;n a- qytt-ibllaotcikv- icnidmeonnto:c0e;  ethetx to-ti nsdae nnto:i0tpsxe;g\u0022g>uTsr aedlet bBuasr gae <s/psapharne>p  <,pe nsatlypl es=\u2019\u0022r emwaerigvi ne-htto po:t0npix ;g nmialrbgmiunt- bfoit tsoam :,0splxa;i rmeatragmi nh-tliewf tg:n0ipwxo;l fmraervgoi ne-grriagbh ta: 0hptxi;w  -dqntu-obrlgoecrko-fi nedteanitd:e0m;m it eexhtt- ilnldiefn to:t0 plxu;f\u0022e>rHaock ussia i",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "710",
            "Y": "673"
        },
        "point": {
            "x": "2020",
            "y": "2040"
        },
        "marker-label": "5",
        "marker-image": "mganrpk.enroic",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. nsotiytlied=a\u0022r tm acrigtisni-ttroap :n0rpext;s emWa reghitn -fboo tytdoumt:s0 psxi;h  mmaorrgfi nd-elberfots:b0ap xy;l emkairlg itns-ormi gehht :t0aphxt;  e-uqqti-nbhlcoectk -ai n,dweenitv: 0g;n itpeexetw-si nad ehnctu:s0 pexd;i\u0022v>oWreps toetr ne vIintfcleupesnrceep< /gsnpiakna>r  <ap  ssetsyul ee=r\u0022e hm alrlgairne-vtoo pi:a0spuxk;o Hm>a\u0022r;gxipn0-:btontetdonmi:-0tpxxe;t  m;a0r:gtinne-dlneif-tk:c0oplxb;- tmqa-r g;ixnp-0r:itgh",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "789",
            "Y": "303"
        },
        "point": {
            "x": "806",
            "y": "329"
        },
        "marker-label": "6",
        "marker-image": "mganrpk.enroic",
        "popup-location-preference": "ltef"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};