var widgetconfig = {
    "background_picture": "2g8p7j5.e6c1574_a4f2b0d19_9S2_2",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "1905",
        "Height": "716",
        "X": "-71",
        "Y": "-02"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.aordgEi nf-ot oepl:p0opexp;  emhatr gfion -sbeostutoohme:r0optxs;  tmpaerkg-ilnl-elwe fdtn:a0 psxg;n imlalregwidn -dreifgohotr:-0dpexr;e i-tq te-hbtl oecrka- irnedteanwt :e0h;t  tgenxitn-iiLn d.esntta:o0bp xr;i\u0022e>h<ts pnaon  esltpyoleep=s\u0022n wfootn th-tfiawm idleyl:l'i.fS Fy aNwSr eTteaxwt 'g;n\u0022i>lCtesnutbr aelh tE doot< /rsepwaeni>v< /eph>t  <tpa esrtty loet= \u0022e-lqbta- psair aeghr a,pehc-ntaytpsei:de mrpatfy ;a  meayreg ienh-tt ogpn:i0lplxu;p  m:aersgnianp-xbeo tsttoim :d0npax ;o dmEa rfgoi nt-rlaeefht :e0hptx ;f om awregiivn -ar isgthnte:s0eprxp;  i-aqstu-kbolHo c,ke-rienHd>e\u0022n;t':t0x;e Tt eSxNt -FiSn.d'e:nytl:i0mpaxf;- tfnoonft -\u0022f=aemliyltys: 'n.aSpFs <N>S\u0022 ;Txepx0t:'t;n\u0022e>d<nbir- t/x>e<t/ p;>0 :<tpn esdtnyil-ek=c\u0022o lmba-rtgqi-n -;txopp0::0tphxg;i rm-anriggirna-mb o;txtpo0m::t0fpexl;- nmiagr",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "466",
            "Y": "61"
        },
        "point": {
            "x": "478",
            "y": "82"
        },
        "marker-label": "1",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "bmoott"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m a.reglionr- teolpb:a0uplxa;v  msatrig ifno- bnootittoamc:i0dpnxi;  rmeahrtgriunf- lae fsta: 0sptxn;a hmcarregmi nd-nrai gehltp:o0eppxs;e d-aqrtt- bhltoicwk -dienkdceanpt :s0i;  otoetx tt-Ii n.duehnstn:o0Hp xf;o\u0022 >d<nsaplasni  sethytl es=s\u0022o rfcoan td-efpaomri ltya:h't. SeFd aNrSt  Tfeox tk'r;o\u0022w>tNeinh otnsbaafs heih<t/ sdpeazni>l<o/bpm>y s< ps ushtty lden=a\u0022 -eqttu-opra readgarratp h\u014d-dtiyapkeo:Te mephtty ;f om anrogiitna-ttso pt:s0rpixf;  emhatr gsianw- btoit tsoam :o0dpEx ;f om ayrtgiicn -elhetf tr:o0fp xk;r ammadrngailn -lrairguhttc:e0tpixh;c r-aq tl-abrltoncekc- ian dseanwt :s0i;h Tt e.xetc-niantdseindt :e0hptx ;n if onnete-sf aembi lnya:c' .iShFs aNbSn oTheixNt 'e;h\u0022t> <sbar  n/w>o<n/kp >e g<dpi rsbt ydleeh=c\u0022r am aerhgti n\u201d-,tnoapp:a0Jp xf;o  meagrdgiirnB-\u201cb oottt ogmn:i0tpaxl;s nmaarrTg>i\u0022n;-'ltexfetT: 0SpNx ;F Sm.a'r:gyilni-mraifg-httn:o0fp x\u0022;= e-lqytt-sb lnoacpks-<i>n\u0022d;exnpt0::0t;n etdenxit-",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "259",
            "Y": "482"
        },
        "point": {
            "x": "239",
            "y": "454"
        },
        "marker-label": "2",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m a.regtiann-utgooph:S0 pexh;t  mfaor geicnn-ebuoltftnoim :c0ipmxo;n omcaer gdinna- lleafcti:t0iplxo;p  meahrtg ifno- rriegdhnti:m0eprx ;a  -sqat -eblltoscakC- ionddEe nfto: 0e;l itfeoxrtp- ienhdte netd:u0lpcxn;i\u0022 >o<ts pearnu ss tsyalwe =i\u0022a sfuoknotH- f,asmdiuloyl:c' .eShFt  NgSn oTmeax tg'n;i\u0022t>aEodlof  Csais ttlie <f/is psaan >r<a/epp>p a< po ts tdyelneo=i\u0022t-iqsto-pp adrnaag riajpuhF- ttynpueo:Me mdpntay ;i hmsaarbgnionh-itNo pe:h0tp xn;e emwatregbi ny-lbeovtittocme:f0fpex ;e tmiaurqg idne-tlaeuftti:S0>p\u0022x;;' tmxaerTg iSnN- rFiSg.h't::y0lpixm;a f--qttn-obfl o\u0022c=ke-liyntdse nnta:p0s;< >t\u0022e;xxtp-0i:ntdneendtn:i0-ptxx;e tf o;n0t:-tfnaemdinliy-:k'c.oSlFb -NtSq -T e;xxtp'0;:\u0022t>h<gbirr -/n>i<g/rpa>m  <;px ps0t:ytlfee=l\u0022- nmiagrrgaimn -;txopp0::0mpoxt;t omba-rngi",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "222",
            "Y": "303"
        },
        "point": {
            "x": "208",
            "y": "372"
        },
        "marker-label": "3",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.aordgEi nl-atrotpn:e0cp xn;i  mlaarngaicn -gbnoitlttosmu:b0 pexh;t  mdanrag ikna-elpe fnti:a0tpnxu;o mm adregtianl-orsiig hdtn:a0 pcxi;o t-sq te-hbtl onceke-witnedbe nnto:i0s;n ette xgtn-iitnsdeernett:n0ip xn;a\u0022 >d<estpaaenr cs tiyalseu=k\u0022o Hf o,netg-afmaim isliyh:t' .nSiF  dNnSa  T,eexrtu't;a\u0022n> Mfoou nytt sFeujjaim< /eshpta nf>o< /rpe>d n<ipm esrt ytlnee=s\u0022e-rqpt--rpeavrea gnraa psha-wt ytpIe :.eemtpatryo;p rmoacrngii no-tt oipa:s0upkxo;H  meakrigli ns-tbsoitttroam :r0opfx ;e rmuatrageifn -elteifrto:v0apfx ;a  msaarwg idnn-ar iegphatc:s0dpnxa;l  -eqste-nbalpoacJk -eihntd ennith:t0i;w  ttenxetm-eilned elnati:t0npexs;s eftonnitu-qf aam isliy :i'j.uSFF  tNnSu oTMe x,te'c;n\u0022a>t<sbird  /e>h<t/ pn>i  <tpf eslt yrleep=p\u0022u  meahrtg inni- tnoepe:S0>p\u0022x;;' tmxaerTg iSnN- bFoSt.t'o:my:l0ipmxa;f -mtanrogfi n\u0022-=leelfytt:s0 pnxa;p sm<a>r\u0022g;ixnp-0r:itgnhetd:n0ip-xt;x e-tq t;-0b:ltoncekd-ni",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "48",
            "Y": "245"
        },
        "point": {
            "x": "140",
            "y": "297"
        },
        "marker-label": "4",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.adregrienp-stoorpp: 0spexi;t imca rggniind-nbuootrtroums: 0dpnxa;  omdaEr ghicni-hlwe fmto:r0fp xs;k rmoawrtgeinn -erdiagrhtt :g0npixv;i r-hqtt -ebhlto cdkn-ai nydteinlta:t0i;v  tceixmto-nioncdee neth:t0 poxt; \u0022s>a< snpoaint ssetgyglues= \u0022e lftobnuts- faa msiplayh:r'e.pS F, eNnSa lTpe xst\u2019'r;e\u0022w>eTirva deeh tB aortgnei< /gsnpialnb>m<u/tp >f i< ps as t,ysllea=i\u0022r-eqtta-mp ahrtaigwr agpnhi-wtoylpfer:eevmop teyg;r amba rag ihnt-itwo pd:n0upoxr;g emraorfg ient-abiodtetmommi: 0ephxt;  lmlairfg iont- lleuffte:r0apcx ;s im airagsiunk-orHi>g\u0022h;t':t0xpexT;  S-Nq tF-Sb.l'o:cykl-iimnadfe-nttn:o0f;  \u0022t=eexlty-tisn dneanpts:<0>p\u0022x;;x pf0o:nttn-efdanmii-ltyx:e't. S;F0 :NtSn eTdenxit-'k;c\u0022o>l<bb-rt q/-> <;/xpp>0 :<tph gsitry-lnei=g\u0022r amma r;gxipn0-:ttofpe:l0-pnxi;g rmaamr g;ixnp-0b:omtot",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "710",
            "Y": "673"
        },
        "point": {
            "x": "724",
            "y": "664"
        },
        "marker-label": "5",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.anrogiitni-dtaorpt: 0cpixt;s imtarrag innr-ebtostetWo me:h0tp xf;o  myadrugtisn -sliehf tm:o0rpfx ;d embarrogsibna- ryilgehkti:l0 ptxs;o m- qeth- btlaohctk -eiunqdiennhtc:e0t;  at e,xwte-iivn dgennitp:e0epwxs; \u0022a> <hscpuasn  esdtiyvloer=p\u0022  ofto netv-iftacmeiplsyr:e'p. SgFn iNkSa rT eax ts'e;s\u0022u> Weersethe rlnl aIrnefvlou einacseu<k/osHp>a\u0022n;>'<t/xpe>T  <SpN  sFtSy.l'e:=y\u0022l-iqmta-fp-atrnaogfr a\u0022p=he-ltyytpse :neamppst<y>;\u0022 ;mxapr0g:itnn-etdonpi:-0tpxxe;t  m;a0r:gtinne-dbnoit-tkocmo:l0bp-xt;q -m a;rxgpi0n:-tlhegfitr:-0npixg;r amma r;gxipn0-:rtifgehlt-:n0ipgxr;a m- q;tx-pb0l:omcokt-tionbd-ennitg:r0a;m  t;exxpt0-:ipnodte-nnti:g0rpaxm;  \u0022f=oenlty-tfsa mpi<l y>:p'/.<S>F/  NrSb <T>e\u0022x;t'",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "789",
            "Y": "303"
        },
        "point": {
            "x": "816",
            "y": "329"
        },
        "marker-label": "6",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};
