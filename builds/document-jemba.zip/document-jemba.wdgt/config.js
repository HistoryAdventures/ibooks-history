var widgetconfig = {
    "background_picture": "1gdpfjf.88f6472_e7f6148_6Sd_03",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "1980",
        "Height": "3600",
        "X": "-02",
        "Y": "-12"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. ssetvyiltea=n\u0022  hmtairwg iynl-btaoipc:o0sp xg;n imlagrngiimn -nbeortdtloimh:c0 prxi;e hmta rdgnian -slreefltt:t0epsx ;h smiatrigriBn -hrtiigwh t,:t0npexm;e l-tqtte-sb lloacikn-oilnodce nlta:e0d;i  teehxtt -siwnodhesn tw:o0rp xt;s\u0022r>iTfh issi hwTo>o\u0022d; xppa0n:etln epdaniin-ttixnegt  u;s0e:st npeidcntio-rkicaoll bf-otrqm-s  ;txop 0e:xtphlgaiirn- nBirgirtaims h; xjpu0s:ttifceel -tnoi gtrhaem  A;bxopr0i:gmiontetso b(-inni gtrhaims  ;ixnps0t:apnocte-,n iignr aTma s\u0022m=aenliyat)s.  pT<h e> nuaspes /o<f. niomiatgaerse ptooo cc odmnmau nniociattcea,r ertantih elru ftehcaane pa  dsehnairmerde dlnaun gtuaahgte ,s eiunsdsiic aethets  foon e",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "-710",
            "Y": "196"
        },
        "point": {
            "x": "-94",
            "y": "177"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>snpaapns /s<t>ynlaep=s\u0022/ <m.atrsgairnt-ntoocp :k0rpaxt;s  mnair gdient-nbeostetropm :s0ip xs;r emlatrtgeisn -llaeifrte:p0mpix ;e hmta rfgoi ny-rreingihft :e0hptx ;d n-aq t,-sbelhotcokl-ci ntdueonhtt:i0w;  etreax to-hiwn d,esnetv:i0tpaxn; \u0022e>h<ts pnaene wstteybl es=e\u0022c nfeornetf-ffiadm ielhyt: 'eFraevHo>r\u0022i;t'",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "-510",
            "Y": "311"
        },
        "point": {
            "x": "-84",
            "y": "391"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>snpaapns /s<t>ynlaep=s\u0022/ <m.asrrgeilnt-tteosp :e0hptx ;y bm anregeisnr-ebvoot teobm :l0lpixw;  smiahrTg i.ne-llbeifstn:o0ppsxe;r  meavrigtiann- reihgth tf:o0 pnxo;i t-uqcte-xbel olcaki-ciindduejn te:h0t;  It etxltu-sienrd elnlti:w0 prxe;l\u0022t>t<essp aan  gsntiylllei=K\u0022  .fsoenctr-ufoasmeirl yr:o'fF asveovriitta'n; \u0022h>tTihwi st criolwf noofc  iomtangie sg nciomnovce y,ss ttnheem eclotntseesq uleannciegsi roof  raibeohrti gmionrafl  svdiroalwetnucoe  dteodwnaarpdxse  thhsei tsiertBt leehrts .s aT hmiesl bboercpa mgen iasna eirnc",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "-310",
            "Y": "454"
        },
        "point": {
            "x": "-34",
            "y": "484"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>snpaapns /s<t>ynlaep=s\u0022/ <m.asrrgeilnt-tteosp :e0hptx ;y bm anregeisnr-ebvoot teobm :l0lpixw;  smiahrtg i,nn-ilaegfAt :.0spexv;i tmaanr gfion -rreidgrhutm: 0ephxt;  r-oqft -sbelnoicgki-rionbdae neth:t0 ;s at etxnte-mihnsdiennutp: 0epmxa;s\u0022 >e<hstp aenc asft ylllei=w\u0022  sfroenltt-tfeasm ielhyT: '.Fyatveoirciots' ;l\u0022a>iSnuorlporci sniin gyltyi,l atuhqies  froo we scnoensv eay s",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "-510",
            "Y": "539"
        },
        "point": {
            "x": "-04",
            "y": "621"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};
