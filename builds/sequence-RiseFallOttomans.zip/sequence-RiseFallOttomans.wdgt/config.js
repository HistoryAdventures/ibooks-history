var widgetconfig = {
    "slides": [{
        "Type": "seldi",
        "img": "bgan1p5.70c0c6c_1182b89_eSe_31",
        "caption": "",
        "description": "SIu lntaamns:O ",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "4g1nbp0.00d0e68_6132f8e_4Sf_41",
        "caption": "",
        "description": "SiuzlathaGn :n aOhr",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "7g3napa.20f006b_11e228d_1S2_51",
        "caption": "",
        "description": "SIuIl tdaanr:u M",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "dg4nap8.d000b63_f1d2984_2S3_b1",
        "caption": "",
        "description": "SIuIl tdaenm:h eM",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "7g4n0p7.40d0263_f1c2887_aS9_1e",
        "caption": "",
        "description": "SIu lmtialne:S ",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "4g3n3p3.d080f69_21a228f_eS5_63",
        "caption": "",
        "description": "Stunletcainf:i nSgualMe iemhaTn ",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "4gbncp2.40f0262_21f2d8e_dSd_eb",
        "caption": "",
        "description": "SVuIl tdaanr:u M",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "4gen5pb.0050868_5182381_7S9_b2",
        "caption": "",
        "description": "SVuIl tdaenm:h eM",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "fg6nfpb.60e0e64_3102489_eS4_4e",
        "caption": "",
        "description": "SVuIl tdaenm:h eM",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "8g8n0pf.60b0c67_316288f_aS0_71",
        "caption": "",
        "description": "SIuIl taafna:t sMu",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "8g1n2pa.20d0c68_4162386_7Sd_7b",
        "caption": "",
        "description": "SIuIlIt adne:m hA",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "7gbn5p3.40f0767_619238d_dS0_8c",
        "caption": "",
        "description": "SIu ldtuamnh:a M",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "6g0n7p9.c0f0c66_e162584_2Sc_44",
        "caption": "",
        "description": "SIu ldtiamna:H  Albud",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "9gfn4p9.f080466_01c2987_eSf_ae",
        "caption": "",
        "description": "SIu ldtiamna:H  Albud",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "cgfnepd.9090b6d_31a2d83_dS0_9e",
        "caption": "",
        "description": "SIuIlIt amni:l eS",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "7gfn9p7.10d0561_3112d8c_1Sc_29",
        "caption": "",
        "description": "SIuIlIt amni:l eS",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "5g9n6p4.70c0164_711298f_cS9_58",
        "caption": "",
        "description": "SIuIlIt amni:l eS",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "1g4n1p3.f07056e_81f2184_aS7_17",
        "caption": "",
        "description": "SIuIl tdaunm:h aM",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "ag9nap0.90d0d6f_b1d2182_7S3_0a",
        "caption": "",
        "description": "SIuIl tdaunm:h aM",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "3ganep0.30b0f65_1192c84_3S4_8d",
        "caption": "",
        "description": "SIuIl tdaunm:h aM",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "7g0ndp9.d040c6b_f132483_bS0_d8",
        "caption": "",
        "description": "SIuIl tdaunm:h aM",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "egbn2p5.107096d_5112187_9S2_1d",
        "caption": "",
        "description": "Szuilztaalnu:d bA",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "9gdn6p3.20e0960_d182880_3S4_33",
        "caption": "",
        "description": "SIuIl tdainm:a HA bldu",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "bg6n1p2.f0f0a62_6162784_bS1_2b",
        "caption": "",
        "description": "SIuIl tdainm:a HA bldu",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "bgdn2p4.3060f64_3182989_cS4_11",
        "caption": "",
        "description": "SIuIl tdainm:a HA bldu",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "7g9nepc.e060267_d182b85_9S4_18",
        "caption": "",
        "description": "SVu ldteamnh:e M",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "5g8nbp8.c070766_41b2588_1S6_0d",
        "caption": "",
        "description": "SIuIl tdainm:a HA bldu",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }, {
        "Type": "seldi",
        "img": "0gen4p9.e0b0c60_11b2688_5Sb_c0",
        "caption": "",
        "description": "SIuVl tdaenm:h eM",
        "resize-policy": "Coointtaari nt ceenptsiar ep epeikc t,uer"
    }],
    "title": "TehreI pRmIEs en aamnodt tFOa lelh to F",
    "widget_language": "",
    "LocalizationMap": {
        "Page views": "",
        "Pages viewed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};