var widgetconfig = {
    "background_picture": "Lgentpt.e1r0-3021__8S4_61",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "1047",
        "Height": "1693",
        "X": "18",
        "Y": "-4"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. asitdynlIe =f\u0022o  msaersgsianl-ct ogpn:i0lpuxr;  emhatr ghitni-wb ostntooimt:a0lpexr;  ymfairdgiilno-sl eoftt :e0rpixs;e dm asrighi no-tr idgehwto: 0spaxw;  s-pqath-rbelpo ctkr-aipn dse\u2019ngtn:i0K;  ethetx tn-oi nsdeecnnte:l0opdxn;o\u0022c> Ghecoursg ef oI IgIn<i/rsepfafno>  e<hpT  s.t)y5l9e7=1\u0022  rmeabrogticnO- t3o1p :n0op xd;e smsaarpg ionh-wb(o thtaojma:l0lpaxW;  nmaahrKg iinl-Al edfetm:m0aphxu;M  mfaor ghitna-erdi gehhtt: 0rpoxf;  s-eqctn-eblloodcnko-ci nsdiehn tr:e0f;f ot eoxtt -kilnudMe nltu: 0npexe;y\u0022a>MK ihnagr moOf  lEun-gtlaadnmdO  fbraowma N1 7o6t0  rteot t1e8l0 1s,i hGte odregnen eIpI I",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "155",
            "y": "1900"
        },
        "marker-label": "",
        "marker-image": "mganrpk.enroic",
        "popup-location-preference": "tpo"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. esntoytl ey=s\u0022o rm asr\u2019gIiInI- teogpr:o0epGx ;g nmiaKr gdient-abioctetropmp:a0 ptxo;n  meavraghi ns-plaehfrte:p0 pdxl;u omwa rkgliunM- rliug htta:h0tp xe;n i-gqatm-ib lnoacck -eiwn d,esnuth:T0 ;. dtneaxlt -si\u2019nhdaejnatl:l0apWx ;f\u0022o> Nhacwuamb  gOnmidtaatc-suilf nOomcr aphu  Mdaeydeneen  CuIlE  Meuhltk <,/sstpraonf>f e< ps isht yrloef= \u0022m imha regsirnu-btmoipe:r0 pnxa;h tm arreghitna-Rb o.tttroomp:p0upsx ;s imhatr gginni-rleefffto: 0npix ;f lmeasrmgiihn -dreitgphutr:k0npaxb;  y-lqrta-ebnl odcakh- i,nhdaejnatl:l0a;W  t,erxots-siencdeednetr:p0 psx\u2019;k\u0022l>uTMh el Ur e.chispiiteinrtB  oefh tt hdinsi hleebt tterro pspeursv erdi eahst  Nwaewrahbt  o,fy rtthneu oCca rrniaethitc  nSit asteec rooff  tnhgei eMruogfh aflo  Eemcpniersee rfpr ogmn i1w7o9r5g  teoh t1 8o0t1 .e sTnhoep sCearr nnait i,cn eShtwa t,es 0w6a7s1  oenhet  oefc ntihse  soelmdiets td riamhp enroi anle ldleapfe nddaehn cyieehst,  tbu",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "1423",
            "Y": "1205"
        },
        "point": {
            "x": "1828",
            "y": "1607"
        },
        "marker-label": "",
        "marker-image": "mganrpk.enroic",
        "popup-location-preference": "tpo"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>t\u201cpWmee :deuplyyt -rhepcaerigvaerda pY-otuqr- \u0022H=ieglhyntess sp'<s  >Lpe/t<t e.ra iddantIe dn ii ns gtnhien eMpopnathh  yolfi aOdc teohbte rm olrafs te.r e.w  .t\u201dr<u/oscp asni>h  <dpn as tIyIlIe =e\u0022g rmoaerGg ignn-itKo pt:n0aptxs;i dm awroghi nt-sbuojt tsoemz:i0spaxh;p mmea rogsilna- lteIf t.:d0opixr;e pm asrighitn -grniigrhutd: 0ypcxa;m o-lqpti-db lfooc ke-cianpd eenhtt: 0n;o  teevxitt-cienpdsernetp: 0eplxb;a\u0022u>lNaovt ee mtohsa ts dtdhai st il eetstuearc ewba se tpoenn noetd  tbnya tKrionpgm iG esoir gsei hITI I. hoanj a1l2l aMWa yf o1 7e9s6i,m erde felhetc tginnigt o<n/ pk>l u<Mp  lsut ymloer=f\u0022  emcanregdinno-ptsoepr:r0opcx ;e hmta rogti ng-nbioytltpoemr: 0npix ;y amlaerdg ihnt-nloemf-tx:i0sp xy;l rmaaerng ian>-\u0022r;ixgph0t::t0npexd;n i--qttx-ebtl o;c0k:-tinned",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "100",
            "Y": "1616"
        },
        "point": {
            "x": "185",
            "y": "1618"
        },
        "marker-label": "",
        "marker-image": "mganrpk.enroic",
        "popup-location-preference": "tpo"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>t\u201cpYmoeu:re pfyrti-ehnpdasrhgiapr aapn-dt qa-l\u0022l=iealnyctes  wpi<t h> pt/h<e. )Berliutri sshi hN antii orno fa ndde mwiiat hd athh ee hE assetv iItnadiitai nCio mlpaacniyt.i l.o p. \u201de<h/ts pfaon >e n<op(  sCtIyEl ee=h\u0022t  mfaor gtihng-itsorpe:v0op xr;e tmaaerrggi ne-tbaogtittosmn:i0 poxt;  nmaalrpg isni-hl enfot :r0epvxo;  kmlaurMg ilnu- rniigwh tn:a0cp>x\u0022;; x-pq0t:-tbnleodcnki--itnxdeetn t;:00:;t nteedxnti--ikncdoelnbt-:t0qp-x ;;\u0022x>pH0e:rteh gKiirn-gn iGgeroarmg e; xIpI0I: tafiemls- ntiog rraemi n;fxopr0c:em otthteoibr- nbiognrda,m  p;exrph0a:ppso ti-nn itghrea mh o\u0022p=ee ltyhtast  ph<e  ><p/",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "1923",
            "Y": "1128"
        },
        "point": {
            "x": "1923",
            "y": "1128"
        },
        "marker-label": "",
        "marker-image": "mganrpk.enroic",
        "popup-location-preference": "tpo"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>t\u201cpYmoeu:re pHyitg-hhnpeasrsg amraayp -rteql-y\u0022 =oenl yatlsl  po<c c>aps/i<o n.sm eutpsoyns  Onuori tianxvaatr isa\u2019bClIeE  aethtta cfhom esneti tainudq efniir me hptr ogtneicdtriaogne.r  .t n.e\u201dn<i/tsnpoacnb>u s< pn asitdynlIe =e\u0022h tm asrsgoirnc-at ospn:o0iptxa;r tmsaurrgfi ng-nbiortetmommi:s0 pexh;t  mnaervgiign -tlreafpt :s0\u2019pkxl;u Mm alrug inno- rdiegthati:c0eprxp;p a- qnte-ebbl oecvka-hi nddleunotc: 0n;o ittecxett-oirnpd ehnctu:S0 p.xn;o\u0022i>tPcreotboarbpl yd ndae stirroipnpgu st og nwiirpeev aowuntu  abnayw aiNl le hwti lslr ebfeftow eIeInI  heigmr oaenGd  gunli KM u,lk",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "131",
            "Y": "1633"
        },
        "point": {
            "x": "105",
            "y": "1235"
        },
        "marker-label": "",
        "marker-image": "mganrpk.enroic",
        "popup-location-preference": "tpo"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};