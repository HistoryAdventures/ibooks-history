var widgetconfig = {
    "background_picture": "eg4nfp1.00f07003f_503080332_2Se_",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "4371",
        "Height": "4852",
        "X": "-3",
        "Y": "-1"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>y/l er=b\u0022< >m\u0022a;r'gtixne-Tt oSpN: 0FpSx.;' :myalrigmianf--btontotfo m;:x0pp0x:;t nmeadrngii-nt-xleetf t;:00:ptxn;e dmnair-gkicno-lrbi-gthqt-: 0;pxxp;0 :-tqhtg-ibrl-oncikg-rianmd e;nxtp:00:;t fteelx-tn-iignrdaemn t;:x0pp0x:;m\u0022o>t<tsopba-nn isgtryalme =;\u0022x pf0o:npto-tf-anmiiglrya:m' .;SyFt pNmSe :Teepxytt'-;h\u0022p>aTrhgea rEanpg-ltiqs-h\u0022 =Seileygtes  opf<  P>opn/d<i>cnhaeprsr/y<,. y1t7i6c0 <n/asipdannI> <n/rpe>h t<upo ss teyhlte =n\u0022i- qdto-optasr asgrreatprha-utqydpaee:he mepstoyh;w  myanragpimno-Ct oapi:d0npIx ;t smaaEr ghicnn-ebroFt teohmt: 0fpox ;s emvairtgaitnn-elseefrtp:e0rp xh;c nmearrFg ienh-tr ilgehptx:e0 poxt;  t-pqmte-tbtlao cokt- isnedcernotf: 0l;a ctoelx th-tiinwd ednetn:i0opjx ;h sfiotnitr-Bf aemhitl y,:e'g.eSiFs  NtSa hTte xntI' ;.\u00220>6<7b1r  n/i> <n/apg>e b< pt ashtty lyer=r\u0022e hmcairdgnionP- tfoop :e0gpexi;S  mhasriglignn-Eb oethtto mf:o0 pnxo;i tmcairpgeidn -al esflta:e0vpexr;  tmia rtgaihnt- reivgehitl:e0bp xs;r a-lqoth-cbsl o,cnko-iitnadteenrtp:r0e;t ntie xott- innedpeon ts:i0 pdxe;t\u0022c>i<psepda ne nsetcysl ee=h\u0022t  feolnith-Wf>a\u0022m;i'ltyx:e'T. SSFN ",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "-86",
            "y": "154"
        },
        "marker-label": "1",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>y/l er=b\u0022< >m\u0022a;r'gtixne-Tt oSpN: 0FpSx.;' :myalrigmianf--btontotfo m;:x0pp0x:;t nmeadrngii-nt-xleetf t;:00:ptxn;e dmnair-gkicno-lrbi-gthqt-: 0;pxxp;0 :-tqhtg-ibrl-oncikg-rianmd e;nxtp:00:;t fteelx-tn-iignrdaemn t;:x0pp0x:;m\u0022o>t<tsopba-nn isgtryalme =;\u0022x pf0o:npto-tf-anmiiglrya:m' .;SyFt pNmSe :Teepxytt'-;h\u0022p>aTrhgea rFarpe-ntcqh- \u0022E=aeslty tIsn dpi<a  >Cpo/m<p>annayp<s//s<p.aeng>e<i/sp >s i<hpt  srteytlfea= \u0022g-nqotl- ptaorna g,r9a6p7h1- tnyip ed:eelmtpntaym;s imda ryglilna-uttonpe:v0ep xs;a wm ayrngaipnm-obco tethoTm :.0spbxu;h  mraireghitn -hlseifltb:a0tpsxe;  omta ragiidnn-Ir ifgoh td:n0aplxn;i a-mq te-hbtl oncok -kicnudretnst :y0e;h tt e,xrte-wionpd elnath:g0upMx ;f of oennti-lfcaemdi leyh:t' .dSeFt oNnS  yTeehxtt 'e;c\u0022n>o< btru b/ >,<t/spr>i f< pt as tryalces=a\u0022g amdaarMg ifno- tdonpa:l0spix ;e hmta rngoi ns-ebtoitst ormi:e0hptx ;t emsa rygeihnT- l.eCfItE: 0ephxt;  fmoa rngoiins-rreivg hhtc:n0eprxF;  e-hqtt -ebtlaoecrkc- iontd esneti:n0a;p mtoecx tl-aitnndeemnntr:e0vpoxg; \u0022l>a<rsepvaens  sdteyglree=m\u0022  gfnoinkt -hfcanmeirlFy :e'h.TS F, nNoSi gTeerx te'h;t\u0022 >nEis tnaibalrirsehte dt uion  gtnhiev r1a6c6 0ysd aaetr ltah ee rbeewh e,shts iotfi rJBe aenh-tB aepktiils t,es tCroalpbreerttn,u otch en aFerpeonrcuhE  Eraeshtt oI ntdaihat  Cgonmipzainlya ewRa s. sdtesseirgentendi  thoc nsetraFk er oaf  caliasiAm  tisna E",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "-27",
            "y": "320"
        },
        "marker-label": "2",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>y/l er=b\u0022< >m\u0022a;r'gtixne-Tt oSpN: 0FpSx.;' :myalrigmianf--btontotfo m;:x0pp0x:;t nmeadrngii-nt-xleetf t;:00:ptxn;e dmnair-gkicno-lrbi-gthqt-: 0;pxxp;0 :-tqhtg-ibrl-oncikg-rianmd e;nxtp:00:;t fteelx-tn-iignrdaemn t;:x0pp0x:;m\u0022o>t<tsopba-nn isgtryalme =;\u0022x pf0o:npto-tf-anmiiglrya:m' .;SyFt pNmSe :Teepxytt'-;h\u0022p>aUrngiaorna pJ-atcqk-<\u0022/=seplaynt>s< /pp<>  ><pp/ <s>tnyalpes=/\u0022<-.qste-iptairnaugmrmaopch -ntayipden:Ie mnpithyt;i wm adreghisni-ltboapt:s0ep xd;a hm ahrsgiitni-rbBo tethotm :t0aphxt;  smeacrngaiinl-llae fstu:o0iprxa;v  meahrtg iont- rsiegdhutl:l0ap xy;l l-aqcti-lbolbomcyks- isnpdaehnrte:p0 ;n otietxatt-niensdeernpte:r0 pdxe;r oflooncti-tflaummi lsyi:h'T. S.Fs tNrSo pTse xgta'l;f\u0022 >e<hbtr  t/a>h<t/ pe>u l<bp  dsntay l,ee=t\u0022i hmwa r,gdienr- tloapc:i0ppyxt;  emhatr gnianh-tb oytttiolma:u0qp xc;i pmoacrsgoidni-elleafkt :e0rpoxm;  am anrog ienk-arti gohtt :,0rpexv;e w-oqht -,belroechk -dienndgeinste:d0 ;y ltleaxitc-eipnsd esnit :t0Ip x.;s\u0022e>c<rsopfa nh ssittyilreB= \u0022f of olnotb-mfyasm illays:r'e.vSiFn uN Sa  Tseax tg'a;l\u0022f> Iknc atJh en olionwUe re hlte ffto  oefc ntehsiesr ph aenhgti negt,o no nlel iw",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "-46",
            "y": "510"
        },
        "marker-label": "3",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>y/l er=b\u0022< >m\u0022a;r'gtixne-Tt oSpN: 0FpSx.;' :myalrigmianf--btontotfo m;:x0pp0x:;t nmeadrngii-nt-xleetf t;:00:ptxn;e dmnair-gkicno-lrbi-gthqt-: 0;pxxp;0 :-tqhtg-ibrl-oncikg-rianmd e;nxtp:00:;t fteelx-tn-iignrdaemn t;:x0pp0x:;m\u0022o>t<tsopba-nn isgtryalme =;\u0022x pf0o:npto-tf-anmiiglrya:m' .;SyFt pNmSe :Teepxytt'-;h\u0022p>aErlgaabroarpa-tteq -F\u0022l=oerlay tasn dp <F a>upn/a<<>/nsappasn/><<./apr>o l<fp  fsot yslden=o\u0022r-fq tg-npiatraaoglrfa pdhn-at yhpsei:fe mhpttiyw;  gmnairmgeient- troepv:i0rp xd;e zmialrygtisn -ab oetbt oomt: 0sprxa;e pmpaar gtianh-wl eefets: 0npaxc;  emnaor g,ienl-prmiagxhet :r0opfx ;, g-nqitg-nbalho cekh-ti nfdoe netg:d0e;  rteewxotl- ienhdte ngtn:o0lpAx ;. efrountta-nf ammoirlfy :n'e.kSaFt  NsSe rTuetxate'r;c\u0022 >h<tbirw  /n>o<i/tpi>s o<ppm osct yelhet= \u0022f om asrtgnienn-otpompo:c0 pexh;t  msaermgairnf- boostltao mt:u0bp x);s nmraertgtianp- lseufoti:r0apvx ;f om asrhgtionl-cr itgrhitk:s0 pdxn;a  -sqntw-obgl oechkt- iontd esnmtr:o0f;i ntue xhts-iitnidreBn tm:o0rpfx(; \u0022g>n<ismpuatns osct yfloe =s\u0022l ifaotnetd- feahmti lsye:r'u.tSpFa cN Sy lTneox tt'o;n\u0022 >hNcoi hdwe t,aginli ginsa hl eeftta roovbearlleo oskiehdt  in",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "-511",
            "Y": "635"
        },
        "point": {
            "x": "-17",
            "y": "676"
        },
        "marker-label": "4",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>y/l er=b\u0022< >m\u0022a;r'gtixne-Tt oSpN: 0FpSx.;' :myalrigmianf--btontotfo m;:x0pp0x:;t nmeadrngii-nt-xleetf t;:00:ptxn;e dmnair-gkicno-lrbi-gthqt-: 0;pxxp;0 :-tqhtg-ibrl-oncikg-rianmd e;nxtp:00:;t fteelx-tn-iignrdaemn t;:x0pp0x:;m\u0022o>t<tsopba-nn isgtryalme =;\u0022x pf0o:npto-tf-anmiiglrya:m' .;SyFt pNmSe :Teepxytt'-;h\u0022p>aCrhgianrtazp<-/tsqp-a\u0022n=>e<l/ypt>s  <pp<  s>tpy/l<e>=n\u0022a-pqst/-<p.aerlabgirsaspohp- tyytpeei:reamvp teyh;t  mraorfg isne-ctnoepi:d0upax ;n ameaprogriunE- bgontotmoam :m0ipaxl;c cmaa rngii nw-elregf td:n0ap xs;c imrabragfi no-criilgahct :o0tp xd;e i-lqptp-ab lsotcnki-ripn dkecnotl:b0d;o otwe xgtn-iisnud eendta:m0 psxa;w  fzotnnti-hfca mlialnyo:i't.iSdFa rNTS  .Tseexitr'u;t\u0022n>e<cb rh t/9>1< /eph>t  <opt  shtty7l1e =e\u0022h tm amrogrifn -rtaolpu:p0oppx ;y lmbairdgeirnc-nbio tstaowm :t0aphxt;  dmnaar g,iani-dlneIf t,:d0apbxa;r emdayrHg i nn-ir idgehtta:n0ipgxi;r o- qtta-hbtl oecukq-iinnhdceentt :a0 ;, ctierxbta-fi nzdtennith:c0 pmxo;r\u0022f> <dseptaane rsct yslaew= \u0022g nfiognnta-hf asmiihlTy>:\u0022';.'StFx eNTS ",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "-412",
            "Y": "801"
        },
        "point": {
            "x": "-37",
            "y": "854"
        },
        "marker-label": "5",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};