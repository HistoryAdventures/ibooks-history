var widgetconfig = {
    "background_picture": "eg4nfp1.00f07003f_503080332_2Se_",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "5300",
        "Height": "5300",
        "X": "-229",
        "Y": "1"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tTphmee :Eenpgylti-shhp aSrigeagrea po-ft qP-o\u0022n=deilcyhtesr rpy<,  >1p7/6<0 <./ystpiacn >n a<ipd nsIt ynlree=h\u0022t-uqots- peahrta gnria pdho-ottysp es:reemtprtayu;q dmaaerhg iens-othowp :y0npaxp;m omCa ragiidnn-Ib ottstaoEm :h0cpnxe;r Fm aerhgti nf-ol esfetv:i0tpaxt;n emsaerrgpienr- rhicgnhetr:F0 pexh;t  -lqetp-xbel ooctk -tipnmdeetntta: 0o;t  tseexctr-oifn dleancto:l0 phxt;i\u0022w> <dbern i/o>j< /hps>i t<ipr Bs teyhlte =,\u0022e gmeairsg itna-htto pn:I0 p.x0;6 7m1a rngii nn-abgoetbt otma:h0tp xy;r rmeahrcgiidnn-olPe ffto: 0epgxe;i Sm ahrsgiilng-nrEi gehhtt: 0fpox ;n o-iqttc-ibpleodc ka->i\u0022n;dxepn0t::t0n;e dtneix-tt-xientd e;n0t::t0npexd;n\u0022i>-Wkhciolleb -tthqe-  s;cxepn0e: tdhegpiirc-tneidg riasm  o;pxepn0 :ttof eiln-tneirgprraemt a;txipo0n:,m ostcthoobl-anrisg rbaeml i;exvpe0 :tphoatt- niitg rraemv e\u0022a=lesl y<t/sp >p <",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "-116",
            "y": "174"
        },
        "marker-label": "1",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tTphmee :Ferpeyntc-hh pEaarsgta rIanpd-itaq -C\u0022o=meplayntys< /ps<p a>np>/ <<.pe gsetiysl es=i\u0022h-tq tr-eptafraa ggrnaoplh -ttoynp e,:9e6m7p1t yn;i  mdaerlgtinna-mtsoipd: 0yplxl;a umtanregvien -sbaowt tyonma:p0mpoxc;  emhaTr g.isnb-ulhe frti:e0hptx ;h smialrbgaitns-er iogth ta:i0dpnxI;  f-oq td-nballoncika-mi nedhetn tn:o0 ;k ctuerxtts- iynedhetn tr:e0wpoxp; \u0022l>a<hbgru M/ >f<o/ pe>n i<lpc esdt yelhet= \u0022d emtaorng iyne-htto pe:c0npox ;t umba r,gtisnr-ibfo tttao mr:a0cpsxa;g amdaarMg ifno- ldenfatl:s0ip xe;h tm anrog isne-triisg hrti:e0hptx ;t e-sq ty-ebhlTo c.kC-IiEn deehntt :f0o;  ntoeixstr-eivn dhecnnte:r0Fp xe;h\u0022t> Eesttaaebrlci sohte ds eiinn atphmeo c1 6l6a0tsn eamtn rtehveo gb elhaersetv eosf  dJeegarne-mB agpntiiks thec nCeorlFb eerhtT,  ,Tnhoei gFerre nechht  Enais tn i<a/rpr>e t< pt usot yglnei=v\u0022r amca rygdiane-rtloap :e0rpexw;  ,mhasrigtiinr-Bb oethtto me:k0iplx ;, smtarragpirne-tlneufotc: 0npaxe;p omraurEg irne-hrtiog htta:h0tp xg;n i-zqitl-abelRo c.ks-tisnedreenttn:i0 ;h ctneexrtF- irnodfe nati:s0Ap xt;s\u0022a>EI nndii am iCaolmcp aan ye kwaatss  doets idgen",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "1777",
            "y": "201"
        },
        "marker-label": "2",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tUpnmieo:ne pJyatc-kh<p/asrpgaanr>a p<-pt qs-t\u0022y=leel=y\u0022t-sq tp-<p a>rpa/g<r.aspehi-ttiynpuem:meomcp tnya;i dmnaIr gniinh-ttiowp :d0ephxs;i lmbaartgsien -dbaoht thosmi:t0iprxB;  emhatr gtianh-tl esfetc:n0apixl;l am asrugoiinr-arvi gehhtt: 0optx ;s e-dqutl-lbal oyclkl-aicnidleonbtm:y0s;  stpeaxhtr-eipn dneonitt:a0tpnxe;s\u0022e>r<pberr  /d>e<r/opl>o c<ipt lsutmy lsei=h\u0022T  m.asrtgrionp-st ogpa:l0fp xe;h tm atraghitn -ebuoltbt odmn:a0 p,xe;t imhawr g,idne-rl elfatc:i0ppyxt;  emhatr gnianh-tr iygthitl:a0upqx ;c i-pqotc-sboldoicekl-aikn deernotm: 0a;  ntoe xetk-aitn doetn t,:r0epvxe;w\u0022o>hI n, etrheeh  ldoewnegri sleedf ty lolfa itcheipss  hsain gtiIn g.,s eocnreo fw ihlsli tniortBe  ftoh el opbrmeysse nlcaes roefv itnhue  aU nsiao>n\u0022 ;Jxapc0k: tfnleadgn i<-/tpx>e t< p; 0s:ttynleed=n\u0022i -mkacroglibn--ttqo-p :;0xppx0;: tmhagrigri-nn-ibgortatmo m;:x0pp0x:;t fmealr-gni",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "246",
            "y": "4709"
        },
        "marker-label": "3",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tEplmaeb:oerpaytte- hFplaorrgaa raanpd- tFqa-u\u0022n=ae<l/ystpsa np><  <>pp /s<t.yalreo=l\u0022f- qfto- psadrnaogrrfa pghn-ittyapoel:fe mdpntay ;h smiafr ghitni-wt ogpn:i0mpexe;t  mraervgiirn -dbeoztitloymt:s0 pax ;e bm aortg isnr-aleepfpta: 0tpaxh;w  meaersg inna-cr iegnhot :,0eplxp;m a-xqet -rbolfo c,kg-niingdneanht :e0h;t  tfeox te-gidned ernetw:o0lp xe;h\u0022t> <gbnro l/A> <./epr>u t<apn  smtoyrlfe =n\u0022e kmaatr gsienr-uttoape:r0cp xh;t imwa rngoiint-ibsootptmoomc: 0ephxt;  fmoa rsgtinne-nloepfmto:c0 pexh;t  msaermgairnf- roisglhat :t0upbx ;) s-nqrte-tbtlaopc ks-uionidreanvt :f0o;  sthetxotl-ci ntdreinkts: 0dpnxa; \u0022s>nNwoo gd eethati lo ti ss mlreoffti nouv ehrsliotoikreBd  mionr ft(h igsn iemluatbsoorca tfeo  hsalnigaitnegd,> \u0022w;hxipc0h: tnnoetd noin-ltyx ecta p;t0u:rtense dtnhie- k<c/opl>b -<tpq -s t;yxlpe0=:\u0022t hmgairrg-inni-gtroapm: 0;pxxp;0 :mtafregli-nn-ibgortatmo m;:x0p",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "-511",
            "Y": "635"
        },
        "point": {
            "x": "-17",
            "y": "2129"
        },
        "marker-label": "4",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tCphmien:tezp<y/ts-phapna>r g<apr aspt-ytlqe-=\u0022\u0022=-eqlty-tpsa rpa<g r>app/h<-.teylpbei:sesmoppt yy;t emiarragvi ne-htto pr:o0fp xs;e cmnaerigdiuna- bnoatetpoomr:u0Ep xg;n ommaar gmiina-llcecfat :n0ip xw;e rmga rdgnian -srciigrhbta:f0 poxc;i l-aqct -obtl odceki-lipnpdae nstt:n0i;r pt ekxcto-libnddoeonwt :g0npixs;u\u0022 >e<dbarm  /s>a<w/ pz>t n<iph cs tlyalneo=i\u0022t imdaarrgTi n.-steoipr:u0tpnxe;c  mhatrngeient-ebnoitnt oemh:t0 poxt;  hmtanregeitnn-elveefst :e0hptx ;m omrafr grianl-urpiogph ty:l0bpixd;e r-cqnti- bslaowc kt-aihntd ednnta: 0,;a itdenxIt -,idnadbeanrte:d0ypHx ; \u0022n>iT hdiest ahnainggiirnog  twaahst  cerueqaitnehdc eftr oam  ,cchiirnbtazf ",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "-412",
            "Y": "801"
        },
        "point": {
            "x": "-37",
            "y": "4961"
        },
        "marker-label": "5",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};