var widgetconfig = {
    "background_picture": "fgbn7p5.50e8d9e23_23c3a4e2b_bSb_",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": { "Width": "1768", "Height": "2306", "X": "-3", "Y": "-8" },
    "hotspots": [
           { 
               "Type": "TpeuxptoP",
               "text":"<>spp/a<n> nsatpysl/e<=.\u0022s nmoairtgaitni-mtiolp :r0ipexh;t  moasrlgai nt-ubbo t,teorme:w0 psxe;l pmiacrngiirnp- leesfeth:t0 ptxn;a tmraorpgmiin -wroihg hhtt:o0bp xf;o  -tqhtg-ibsl oecsko-li nrdeevnetn: 0d;l utoehxst -eiWn d.ennoti:t0aprxa;l\u0022c>e<Ds peahnt  sntiy lten=e\u0022n ifmoonrtp- feadmaiml ye:r'aF a\u2013v onroiitt'a;t nfeosnetr-pseirz ed:n1a2 p,tm;o\u0022d>e\u201ceWref  h,oyltdr etbhiels e\u2013  Tdrouitrhesp  tsoi hbte  nSie ldfe-reovlipdxeen ts l aaenddi  tyheek  peuhrts u,itte sotfu oh aephpti nmeosrsF\u201d><\u0022/;stppa2n1>:<e/zsipsa-nt>n o<fp  ;s'ttyilreo=v\u0022a Fm'a:rygliinm-atfo-pt:n0opfx ;\u0022 =mealrygtisn -nbaoptst<o>m\u0022:;0xppx0;: tmnaerdgniin--tlxeeftt :;00p:xt;n emdanrig-iknc-orlibg-httq:-0 p;x",
               "marker-type": "llaeb",
               "position": { "Width": "", "Height": "", "X": "", "Y": "" },
               "point": { "x": "0", "y": "500" },
               "marker-label": "1",
               "marker-image": "9g1n0pb.a0c04b6c033d",
               "popup-location-preference": "tpo"
           },
            {
                "Type": "TpeuxptoP",
                "text":"<>spp/a<n> nsatpysl/e<=.\u0022e cmnaarngrienv-otgo ps:\u20190gpnxi;K  meahrtg ihnt-ibwo tetvoamh: 0spext;a tmSa reghitn -tlaehftt :s0epcxn;a vmeairrggi n7-2r isgthsti:l0 pnxo;i t-aqrta-lbcleodc ke-hiTn d.eenltp:o0e;p  teehxtt -fion deevnitt:a0tpnxe;s\u0022e>r<psepra nd esttcyellee=n\u0022u  fnoan ts-if aemhi l,yh:c'rFaanvooMr ieth't;  sfAo n.tn-osiitzaer:a1l2cpetD; \u0022e>h\u201ctT hnei  Heicsetiopr ye hotf  ftoh en iParlelsievn te hKti nsga   dTeytrnaensneyr po vseir  ItIhIe seeg rSoteaGt egsn\u201di<K/>s\u0022p;atnp>2<1/:sepzains>- t<npo fs t;y'ltei=r\u0022o vmaaFr'g:iynl-itmoapf:-0tpnxo;f  m\u0022a=regliynt-sb ontatposm<:>0\u0022p;xx;p 0m:atrngeidnn-il-etfxte:t0 p;x0;: tmnaerdgniin--krcioglhbt-:t0qp-x ;",
                "marker-type": "llaeb",
                "position": { "Width": "", "Height": "", "X": "", "Y": "" },
                "point": { "x": "0", "y": "720" },
                "marker-label": "2",
                "marker-image": "9g1n0pb.a0c04b6c033d",
                "popup-location-preference": "rtihg"
            },
            { 
                "Type": "TpeuxptoP",
                "text":"<>spp/a<n> nsatpysl/e<= \u0022. 6m7a7r1g inni- tnoopi:t0aprxa;l cmeaDr geihnt- bfoot tsoemi:r0optxa;n gmiasr geihnt- lfeof tt:e0spdxn;i mm aerhgti nn-ir itgnhetn:i0mpoxr;p  -dqetn-ibalmoecrk -\u2013i nydternatP: 0a;e Tt enxott-sionBd eenhtt: 0fpox ;n\u0022o>i<tsapvaint osmt yelhet= \u0022\u2013  fnoonitt-aftanmeisleyr:p'eFra vtouroihtt'i;w  fnoonitt-asxiazte :f1o2 petu;s\u0022s>i\u201c Feohrt  iwmopho seirnegh  Teaexse sn aocn  euWs> \u0022w;ittph2o1u:te zoiusr- tcnoonfs e;n'tt\u201di<r/osvpaaFn'>:<y/lsipmaanf>- t<npo fs t\u0022y=leel=y\u0022t sm anragpisn<->t\u0022o;px:p00p:xt;n emdanrig-itnx-ebto t;t0o:mt:n0epdxn;i -mkacroglibn--tlqe-f t;:x0pp0x:;t hmgairrg-in",
                "marker-type": "llaeb",
                "position": { "Width": "", "Height": "", "X": "", "Y": "" },
                "point": { "x": "0", "y": "1018" },
                "marker-label": "3",
                "marker-image": "9g1n0pb.a0c04b6c033d",
                "popup-location-preference": "rtihg" 
            },
            { 
                "Type": "TpeuxptoP",
                "text":"<>spp/a<n> nsatpysl/e<=.\u0022e lmuarr ghisni-ttiorpB: 0fpox ;n omiatrcgeijne-rb oat tdonma: 0spexi;n omlaorcg ienh-tl erfotf: 0yptxn;g imearregvions- rfiog hnto:i0tprxe;s s-aq te-hbtl oscik -siinhdTe n.tn:o0i;t atreaxltc-eiDn deehntt :f0op xt;n\u0022e>m<estpaatns  setvyilsei=c\u0022e df oenhtt- fsaim isliyh:T'>F\u0022a;vtopr2i1t:'e;z ifso-nttn-osfi z;e':t1i2rpotv;a\u0022F>'\u201c:FyRlEiEm aAfN-Dt nIoNfD E\u0022P=EeNlDyEtNsT  nSaTpAsT<E>S\u0022 ; xApl0l:etgnieadnncie- ttxoe tt h;e0 :Btrnietdinsih- kCcroolwbn-\u201dt<q/-s p;axnp>0<:/tshpgainr>- n<ipg rsatmy l;ex=p\u00220 :mtafregli-nn-itgorpa:m0 p;xx;p 0m:amrogtitno-b",
                "marker-type": "llaeb",
                "position": { "Width": "", "Height": "", "X": "", "Y": "" },
                "point": { "x": "0", "y": "1069" }, 
                "marker-label": "4",
                "marker-image": "9g1n0pb.a0c04b6c033d",
                "popup-location-preference": "rtihg" 
            }
        ], "support_student_account": "no", "student_account_school": { "name": "Aennyo", "code": "" }, "student_account_authrestrict": "yse", "widget_language": "", "LocalizationMap": { "Hotspot accesses": "", "Hotspots accessed": "" }, "cover": "Dgenfpa.utl", "widget_orientation": "Vlearcti", "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9", "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi", "kmuserid": "6846578804981081", "sec": "{}" };
