var widgetconfig = {
    "background_picture": "dg7pajd.e82687b_3991e5c_1Sa_c9",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "1453",
        "Height": "2023",
        "X": "-51",
        "Y": "-12"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>snpaapns /s<t>ynlaep=s\u0022/ <m.alrlgiitns- ttolpu:c0ipfxf;i dm aerrgoimn -ebmoatcteobm :,0lpaxr;t umeanr gyilnl-alceiftte:r0opexh;t  mearregwi no-hrwi g,hatr:e0Pp xn;i  -eqste-obnleoGc ke-hitn dyebn ts:e0i;l ptpeuxst -fion dtennetm:e0vpoxm; \u0022e>h<ts p,asnr esttaywl ee=h\u0022t  fgonnitl-wfoarmpi lsyp:i'hFsa vnoarmiott't;O  fhotnitW- s.iszree:d1n2epfte;d\u0022 >eHhetr eo,t  ownoel bc aenr esveees  tah et lOatetdo mtain  tfuobr c,enso iutnadseirntaagkrion gl atchiet scioglools sfaol  hepfmfuoirrtt  oaf  ytlrnaon stpoonr tsianwg  stghoeli rd esshaieprsg  ofvoe rd aloarn ds \u2019tdoe msheeeM  t.hgenmi rseatfneel ym opruft  sopuith si nk ctohleb  Gootl dyeanw  Hroertna.w  Tehhits  swsaosr coar dreerierdr abby  nMieahhmce dl aIsIs obleocca uas ed etthcee rBey zdaanht isnree ddneef",
        "marker-type": "llaeb",
        "position": {
            "Width": "",
            "Height": "",
            "X": "",
            "Y": ""
        },
        "point": {
            "x": "435",
            "y": "760"
        },
        "marker-label": "1",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> nsatpysl/e<=.\u0022s emcanregfiend- teohpt: 0fpox ;t rmaapr gai ns-abwo tttaohmt: 0,p\u2019xs;i cmaalrgg inne-\u2018l eefhtt: 0,phxc;t imda rpgeiend- reihgth ts:d0rpoxc;e r- qots-lbal oechk -dinnad e,nrte:h0t;o  teehxtt -oitn deednits: 0epnxo; \u0022m>o<rsfp asne lsitmy l6e =g\u0022n ifeobn ts-af asmlillayw: 'eFhatv ofroi th't;g nfeoln te-hsti zsee:t1a2mpitt;s\u0022e> BerHo q.usie\u00e8crnee\u2019fse dw odrrka widsn anlo tso\u2019reilopuosnliyt nsactasnnto Co ns eabricrhcisteedc tousrlaal  edre\u00e8tiauiqlosr Bo f. \u201dtehger oceiGt yt So ff oC osntsitaarnttsi neohptl ey.b  Adletdhnouuogbh  ehdei si se nkoe ehnt itwo  ,perlogvniadier td eat afiol emdr oifn feohrtm agtniiovna ho\u201cn  ,tshae  ymtaincy  echhtu rfcoh enso iitnp itrhces ecdi teyh,t  hyilsr ailsu cai twroarpk  ,lneosist ciinpteedr essithetd  dienc ntehuel fanric hyilttencetduirvael  dfnaab rdiecn ioaft ntohce  ecriat ys.l iRaattehde re,m ohse  ,irse vaelwtooHg>e\u0022t;htepr2 1m:oerzei si-nttneorfe s;t'etdi rionv atFh'e: yelcicmlaefs-itansotfi c\u0022a=le lmyytsst enraipess< >c\u0022o;nxtpa0i:ntende dwniit-ht xtehte  ;c0h:utrncehdensi,- kacnodl bo-ft qt-h e; xppe0o:ptlheg ihre- neingcroaumn t;exrps0 :otnf ehli-sn itgrraavme l;sx pa0r:omuontdt otbh-en icgirtaym. <;/xspp0a:np>o<t/-snpiagnr>a m< p\u0022 =setly",
        "marker-type": "llaeb",
        "position": {
            "Width": "",
            "Height": "",
            "X": "",
            "Y": ""
        },
        "point": {
            "x": "899",
            "y": "830"
        },
        "marker-label": "2",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "tpo"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. esrtiyplmee= \u0022e nmiatrngaizny-Bt oeph:t0 pnxi;  nmoairggiilne-rb odtntao mr:e0wpoxp;  rmaalrugciens- lneefetw:t0epbx ;p imhasrngoiint-arliegrh te:s0oplxc;  e-hqtt -obtl oscak -sinnodietnatc:i0d;n it erxetr-aienldce nwte:f0 pexb; \u0022d>lDueoscp ietree haT >r\u0022a;txhpe0r: tfnreudsntir-attxientg  ;l0a:ctkn eodfn ii-nktceorlebs-tt qi-n  ;txhpe0 :utrhbgainr -fnaibgrriacm  o;fx pC0o:ntsftealn-tniingorpalme ,; xBpr0o:qmuoit\u00e8troeb -nneivgerratmh e;lxeps0s: pdoetd-inciagtreasm  a\u0022 =seilgyntisf ipc<a n>tp /s<e.crtoiroenp moef  ehniist ndaezsycBr ilpatniiofn  eohft  t,hIeX  ceintiyt ntaot stnhoeC  cfhou rrcohs soefc eHdaegripa  eShotp h,iIaI.V  Ascucgoorldoienlga Pt on hBorJo qruoir\u00e8erpem,E  tehhits  diesd ujlucsnti  oensee hoTf  .tehmei tm aenmya s\u201c heahntd stoam ee\u201dc icvhruersc heehst  ignn itdhnee tctiat yy lbiumta ft hlaati rietp miis  ethhte  wmaoss td nrae m,ayrxkoadbolhet.r OT hniis  yitsi rcoohntfuiar mleadu tbiyr itphse  tislelhugsithr aethito n,,e lwphoinciht nuastessn otCh ef ot ohwcerraiinrgt afPi geuhrte  yobf  dHealg ieac iSvorpehsi aa  adse dsnoemtettah ienHg  .o\u201dfe cainv riecso neinci vriedp rgensiemnrtoaftrieopn  sokfe etrhGe  echitt yf.o  Trheen naarmt ieshtt  hsosweenvteirw,  oits  sculoeiarrulcy  snaowt  If\u201ca m:ielciiavrr ewsi txho dtohhet rsOh anpae  dannedt tsat yolte  soufo iOrrutch ogdnoixe bc houtr csheesss.e fWnhoecr eears\u00e8 iBurqooqruBi \u00e8driel oohftfaeCr sa  as ac l;eyatri sdoeisrcurci pdtniao nh toifa ft hnew or osuinhd eydb  sdheatpaev iotfo mH angeieab  Seovpahhi ao,t  tshrea eaprptai shtc rhuehrce  ehhats  fdoe pniocittepdi rtchsee dc hsu\u2019recrh\u00e8 iiunq oar Bm>u\u0022c;hx pm0o:rten erdencio-gtnxiesta b;l0y: tEnuerdonpie-aknc,o labl-mtoqs-t  ;Gxopt0h:itch gsitry-lnei,g rnaomt a;bxlpy0 :itnf etlh-en iggrreaamt  ;cxepn0t:rmaolt troobs-en iwgirnadmo w; xopn0 :tphoet -fnai\u00e7gardaem. <\u0022/=seplaynt>s  <p",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "309",
            "Y": "216"
        },
        "point": {
            "x": "995",
            "y": "650"
        },
        "marker-label": "3",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "bmoott"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n  .sstryelden=e\u0022f emda regniint-ntaozpy:B0 pfxo;  smraerbgmiunn- bgontitlodmn:i0wpdx ;d nmaa rtgniant-sliedf te:h0tp xo;t  mtasragritnn-orci gdhetk:r0apmx ;n i- qdtn-abtlso cyke-hitn d,ernuto:m0r;a  tneexdtl-oign dnein te:s0spaxm;-\u0022n>eA lttnheodungehl pBsreoRq u.ie\u00e8lrpeo nwiatsn antostn owCi tfnoe sssr etdon etfheed  sniaeigtes,i rthhCe  edhetp incathito nr eohft aCro n,sdtnaunotrigneorpolfe  echotn tIa ignneids swaimt hyimnr at hniasm oitltlOu sethrta tneod  svneirasmieorn  soufc ohfi se hwto rtka hwta sn ociltecairpleyd  isnifhltu ennic eedt obny  oott hgenri tcsoenrteetmnpio roasrlya  ssoiu rtcIe>s\u0022.; xHpe0r:et noenden ic-atnx este e; 0c:ltenaerdlnyi -tkhceo libm-ptrqe-s s;ixvpe0 :atrhrgaiyr -onfi gernaomr m;oxups0 :ctafnenlo-nn itghraatm  t;hxep 0S:umlottatno bM-enhimgerda mI I; xhpa0s: paortr-anyiegdr aamg a\u0022i=neslty ttsh ep <B y>znaanptsi/n<e. ndoenfneancd earcsi.l iTshaeB  iyltlhugsitmr ast\u2019inoanb,r Ot hfroo utgrho plearc kai nygb  idne rsiopmsen id estia ielrse,h  nsenvoeirttahretlseuslsl im ask\u2019erse icnlreeavra Tn oetL  ofnol ye ntoh er evhatseth ws irzeed noofw  tohte stef eela rsliy  ecnaOn n.oencsn,a tbsunti  arlosfo  dtnhueo rlgo geihstt ioctanli  cgounds iydleerrautcieosn sg niinevbo levteadt iisns edcierne cotti nnge etsh eeibr  nfaicr ey.e hT",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "471",
            "Y": "475"
        },
        "point": {
            "x": "1003",
            "y": "994"
        },
        "marker-label": "4",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "ltef"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};