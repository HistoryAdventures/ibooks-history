var widgetconfig = {
    "background_picture": "dg7pajd.e82687b_3991e5c_1Sa_c9",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "1453",
        "Height": "2023",
        "X": "-51",
        "Y": "-12"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.alrlgiitns- ttolpu:c0ipfxf;i dm aerrgoimn -ebmoatcteobm :,0lpaxr;t umeanr gyilnl-alceiftte:r0opexh;t  mearregwi no-hrwi g,hatr:e0Pp xn;i  -eqste-obnleoGc ke-hitn dyebn ts:e0i;l ptpeuxst -fion dtennetm:e0vpoxm; \u0022e>h<ts p,asnr esttaywl ee=h\u0022t  fgonnitl-wfoarmpi lsyp:i'hFsa vnoarmiott't;O  fhotnitW- s.iszree:d1n2epfte;d\u0022 >eHhetr eo,t  ownoel bc aenr esveees  tah et lOatetdo mtain  tfuobr c,enso iutnadseirntaagkrion gl atchiet scioglools sfaol  hepfmfuoirrtt  oaf  ytlrnaon stpoonr tsianwg  stghoeli rd esshaieprsg  ofvoe rd aloarn ds \u2019tdoe msheeeM  t.hgenmi rseatfneel ym opruft  sopuith si nk ctohleb  Gootl dyeanw  Hroertna.w  Tehhits  swsaosr coar dreerierdr abby  nMieahhmce dl aIsIs obleocca uas ed etthcee rBey zdaanht isnree ddneef",
        "marker-type": "llaeb",
        "position": {
            "Width": "",
            "Height": "",
            "X": "",
            "Y": ""
        },
        "point": {
            "x": "435",
            "y": "760"
        },
        "marker-label": "1",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.asregcinne-fteodp :e0hptx ;f om atrrgaipn -ab ostatwo mt:a0hptx ;, \u2019msaircgailng- lneef\u2018t :e0hptx ;, hmcatrigdi np-ereidg heth:t0 psxd;r o-cqetr- bolsolcak -eihn ddennat :,0r;e htteox te-hitn doetn te:d0ipsx ;e\u0022n>o< smpoarnf  ssteylliem= \u00226  fgonnite-bf asmai lsyl:l'aFwa veohrti tf'o;  hftognnte-ls iezhet: 1s2eptta;m\u0022i>tBsreo qeuHi \u00e8.rsee\u2019csn ewfoerdk  dirsa wndontaolr iso\u2019uesllpyo nsictannatt sonno Ca rscehbiitreccsteudr aols ldae teari\u00e8lisu qoofr Bt h.e\u201d ecgirtoye Go ft SC ofnos tsatnitairntosp leeh.t  Aylbt hdoeudgnhu ohbe  eidsi sk eeenno  thot ipwr o,veildgen adiertta ial efdo  imnrfoofr meahtti ognn iovna ht\u201ch e, smaa nyyt icch uerhcth efso  inno itthpei rccisteyd,  ehhits  yilsr aal uwcoirtkr alpe s,sn oiinttceirpeesdt esdi hitn  dtehcen eaurlcfhniit eyclttunreadli vfea bdrniac  doefn itahten occi teyr.a  Rsaltihaetre,d  heem oiss  ,arletvoegweotHh>e\u0022r; tmpo2r1e: eiznitse-rtensotfe d; 'itni rtohvea Fe'c:cylleismiaafs-ttincoafl  \u0022m=yesltyetrsi ensa pcso<n>t\u0022a;ixnpe0d: twnietdhn it-htex ecth u;r0c:htense,d nain-dk coofl bt-hteq -p e;oxppl0e: thheg iern-cnoiugnrtaemr s; xopn0 :htifse lt-rnaivgerlasm  a;rxopu0n:dm otthteo bc-intiyg.r<a/ms p;axnp>0<:/ppo>t -<npi gsrtayml e\u0022==\u0022e-lqytt-sp apr<a g>rpa/p<h>-/t yrpbe<:>e\u0022m;pttpy2;1 :meazrigsi-nt-ntoofp :;0'ptxi;r omvaarFg'i:ny-lbiomtatfo-mt:n0opfx ;; xmpa0r:gtinne-dlneif-tt:x0eptx ;; 0m:atrngeidnn-ir-ikgchotl:b0-ptxq;- ",
        "marker-type": "llaeb",
        "position": {
            "Width": "",
            "Height": "",
            "X": "",
            "Y": ""
        },
        "point": {
            "x": "899",
            "y": "830"
        },
        "marker-label": "2",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "tpo"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.aerrgiipnm-et oepn:i0tpnxa;z ymBa reghitn -nbio tntooimg:i0lpexr;  dmnaar grienw-olpe frta:l0upcxe;s  mnaeregwitne-br ipgihhts:n0opixt;a l-eqrt -ebsloolcck -eihntd eontt :s0a;  stneoxitt-aicniddennit :r0eprxa;e\u0022l>c< swpeafn  esbt ydlleu=o\u0022c  feorneth-Tf>a\u0022m;i'ltyx:e'T. SSFN  NFSS .T'e:xytl'i;m\u0022a>fD-etsnpoift e\u0022 =ae lryattsh enra pfsr<u>s\u0022t;rxapt0i:ntgn eldancik- toxfe ti n;t0e:rtensetd niin- ktchoel bu-rtbqa-n  ;fxapb0r:itch goifr -Cnoingsrtaamn t;ixnpo0p:ltef,e lB-rnoiqguria\u00e8mr e; xnpe0v:emrotthteolbe-snsi gdreadmi c;axtpe0s: pao ts-ingingirfaimc a\u0022n=te lsyetcst ipo<n  >opf/ <h>i/s  rdbe<s>c\u0022r;i'pttxieoTn  SoNf  FtSh.e' :cyiltiym atfo- ttnhoef  c;hxupr0c:ht noefd nHia-gtixae tS o;p0h:itan.e dAncic-okrcdoilnbg- ttqo-  B;rxopq0u:it\u00e8hrgei,r -tnhiigsr aims  ;nxopt0 :jtufsetl -onnieg roafm  t;hxep 0m:amnoyt t\u201cohba-nndisgormaem\u201d  ;cxhpu0r:cphoets- niing rtahme  ;cyittpym,e :beupty ti-th piasr gtahrea pm-otsqt- \u0022r=eemlayrtksa bpl<e .> pT/h<i>sn aipss /c<o.nrfoirrempemde  beyn itthnea ziylBl ulsatnriaft ieohnt,  ,wIhXi cehn iutsneast stnhoeC  tfoow erroisnsge cfeidgeurrpe  eohft  H,aIgIiVa  sSuogpohlioae laasP  snohmoeJt hrionrge pomfE  aenh ti cdoendiucl crneip reesseehnTt a.teimoint  oefm atsh ee hcti ttya.  eTchiev raerst ieshtt  hgonwiedvneert,t ai sy lcilmeaafr llya inroetp mfia meihlti awra sw idtnha  t,hyex osdhoahpter Oa nndi  syttyilreo hotfu aO rltahuotdiorxi pcsh utrscehhegsi.h  Wehhetr e,aesl pBornoiqtunia\u00e8trsen ooCf ffeor sh car acilretaarP  deehstc ryibp tdieoln  eocfi vtrhees  rao udneddende tsthaa peeH  o.f\u201d eHcaigvirae sS oepnhiivai,d  tghnei marrotfirsetp  hsekreee rhGa se hdte pfioc treedn ntahme  echhtu rscshe nitni wa  omtu cshu omiorruec  rseacwo gIn\u201ci s:aebcliyv rEeusr oxpoedaonh,t raOl mnoas td nGeottthai co ts tsyuloei,r unco tganbileyb  iont  tshees sgerfenaotc  ceern\u00e8tiruaqlo rrBo s,ec iwlionhdtoawC  oan  stah e; yftai\u00e7saodier.u<c/ sdpnaan >h<t/ipa>f  <npw os tsyilhe =y\u0022b- qdte-tpaavriatgorma pnhe-etby peev:aehm potty ;s rmaaerpgpian -htcorpu:h0cp xe;h tm afrog inno-ibtoptitrocms:e0dp xs;\u2019 emra\u00e8riguiqno-rlBe>f\u0022t;:'0tpxxe;T  mSaNr gFiSn.-'r:iyglhitm:a0fp-xt;n o-fq t\u0022-=belloyctks- innadpesn<t>:\u00220;;x pt0e:xttn-eidnndie-nttx:e0tp x;;0 :ftonnetd-nfia-mkicloyl:b'-.tSqF-  N;Sx pT0e:xtth'g;i\u0022r>-<nbirg r/a>m< /;px>p 0<:pt fsetly-lnei=g\u0022r amma r;gxipn0-:tmoopt:t0opbx-;n imgar",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "309",
            "Y": "216"
        },
        "point": {
            "x": "995",
            "y": "650"
        },
        "marker-label": "3",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "bmoott"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m a.rsgriend-nteofpe:d0 pexn;i tmnaarzgyiBn -fboo tstroemb:m0upnx ;g nmialrdgniinw-dl edfnta: 0tpnxa;t smiadr geihnt- roitg htts:a0rptxn;o c- qdte-kbrlaomc kn-ii nddneantts: 0y;e htte x,tr-uionmdrean tn:e0dplxo;g\u0022 >n<is peasns asmt-ynlee =t\u0022n efdonnetl-pfsaemRi l.ye:l'p.oSnFi tNnSa tTsenxotC' ;f\u0022o> Aslrtehdonuegfhe dB rnoaqiutis\u00e8irreh Cw aesh tn onta hwti trneehstsa rt o, dtnhueo rsgieergoef,  ethhte  ndie pgincitsisoanm  oyfm rCao nnsatmaontttiOn oephlte  ncoo nstnaiianmeedr  wsiutchoifn  ethhti st aihltl unsotirtactiepde dv esrishito nn io fe thoins  owto rgkn iwtasse rceltenair loys lian fsliu etnIc>e\u0022d; 'btyx eoTt hSeNr  FcSo.n't:eymlpiomraafr-yt nsoofu r\u0022c=eesl.y tHse rnea posn<e> \u0022c;axnp 0s:eten ecdlneia-rtlxye tt h;e0 :itmnperdensis-ikvceo labr-rtaqy-  o;fx pe0n:otrhmgoiurs- nciagnrnaomn  ;txhpa0t: ttfheel -Snuilgtraanm  M;exhpm0e:dm oItIt ohba-sn iagrrraamy e;dx pa0g:apionts-tn itghrea mB y\u0022z=aenltyitnse  pd<e f>epn/d<e>r/s .r bT<h>e\u0022 ;i'ltlxuesTt rSaNt iFoSn.,' :tyhlriomuagfh- tlnaocfk i;nxgp 0i:nt nseodmnei -dtexteati l;s0,: tnneevdenrit-hkecloelsbs- tmqa-k e;sx pc0l:etahrg inro-tn iognrlaym  t;hxep 0v:atsfte ls-inzieg roafm  t;hxeps0e: meoatrtloyb -cnaingnroanms ,; xbpu0t: paolts-on itghrea ml o;gyitsptmiec:aelp ycto-nhspiadregraartaipo-ntsq -i\u0022n=veollyvtesd  pi<n  >dpi/r<e>cntaipnsg/ <t.hneoinrn afci raec.i lTihseayB  cyatnh gbiem  sse\u2019enna btroO  nfeoc etsrsoipteart ea  byebi ndge rsiepcsunrie lsyi  deurge hi nstnoo itthaer tgsruolulnid  sf\u2019orre iinnrsetvaanTc ee.L  Ofnoe  einso  lreefhtt ethow  wroend",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "471",
            "Y": "475"
        },
        "point": {
            "x": "1003",
            "y": "994"
        },
        "marker-label": "4",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "ltef"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};