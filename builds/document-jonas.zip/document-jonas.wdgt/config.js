var widgetconfig = {
    "background_picture": "7gbp4j8.c0d8e4f_24f2c0614_fSc_d",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "5000",
        "Height": "2348",
        "X": "-91",
        "Y": "-81"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m a.rtgpiinr-ctsoepd:-0npoxn;  ymlaervgiitna-lbeort tnoima:m0eprx ;, amnairhgCi nf-ol eefnti:l0tpsxa;o cm atrsgaivn -erhitg hrto: 0apcxi;r e-mqAt -hbtlroocNk -fion dtesnato:c0 ;n rteetxsta-ei nedhetn tf:o0 pexs;o\u0022h>t< sepkainl  s,tsyrleeh=t\u0022o  f;onnoti-sfiacmeirlpy :f'o. SlFe vNeSl  Tneixatt'r;e\u0022c> Aa  1t6ctehl fCeern t,uarcyi rVeimeAw  hotfu otSh en rWeotrslade< /dsnpaa na>c<i/rpf>A  <npr eshttyrloen= \u0022f-oq te-spoahrta gerkaiplh -,tsyepnei:letmspatoyc;  emmaorsg i:ne-btoolpg: 0ephxt;  dmnaurogrian -dbaoetrtposm :d0aphx ;s nmoairtgailnu-ploepf tn:a0eppxo;r umEa rrgaifn -wroihg htts:u0jp xf;o  -eqstn-ebsl oac ks-yienvdneonct :y0l;l atceixfti-cienpdse nttI: 0.pdxo;i rfeopn te-hfta mniil yd:e'w.eSiFv  NsSa wT edxltr'o;w\u0022 >e<hbtr  w/o>h< /fpo>  t<oph ssptaynlse =c\u0022i tmsaartgnianf- tao ps:e0spaxc;w omhasr gyirnu-tbnoetct ohmt:601p xy;l rmaaer geihnt- lmeofrtf: 0eprxe;h pmsairngailnp- rsiighhTt>:\u00220;p'xt;x e-Tq tS-Nb lFoSc.k'-:iynldiemnatf:-0t;n otfe x\u0022t=-eilnydtesn tn:a0ppsx<;>\u0022",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "368",
            "y": "244"
        },
        "marker-label": "1",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>y/l er=b\u0022< >m\u0022a;r'gtixne-Tt oSpN: 0FpSx.;' :myalrigmianf--btontotfo m;:x0pp0x:;t nmeadrngii-nt-xleetf t;:00:ptxn;e dmnair-gkicno-lrbi-gthqt-: 0;pxxp;0 :-tqhtg-ibrl-oncikg-rianmd e;nxtp:00:;t fteelx-tn-iignrdaemn t;:x0pp0x:;m\u0022o>t<tsopba-nn isgtryalme =;\u0022x pf0o:npto-tf-anmiiglrya:m' .;SyFt pNmSe :Teepxytt'-;h\u0022p>aFrrgoamr aRpi-stkqy- \u0022O=reilgyitnss <p/<s p>apn/><<>/npa>p s</p< .ssttyalceu=d\u0022 -dqlto-gp aervalgerwatp hf-ot ympues: eemhptt yn;i  moaortg itni- troopf: 0yplxe;m omsadrngaihn -dbioatpt oyml:d0eptxr;o pmraurpg ienk-ulDe feth:T0 p.xy;a dm asrtgii nf-or iyghhpta:r0gpoxe;g  -lqatb-obllgo cdke-tinnedmeuncto:d0 ;y lteevxits-nientdxeen tt:s0opmx ;e hfto nfto- feammoisl yd:e's.aScFw oNhSs  Tpeaxmt 's;i\u0022h>t< bdrn a/ >,<e/bpo>l g< pe hstt yfloe =s\u0022a emraar gwienn- tgonpi:t0rpaxh;c  moatr geimna-cb ottit onme:h0wp xs;r omtairtgeipnm-olce fnta:e0ppoxr;u Em arrigeihnt- rfiog hdta:e0hpax ;e r-eqwt -ebsleoucgku-tirnodPe neth:t0 ;e stueaxcte-Bi n?dpeanmt :a0 pexl;g\u0022g>u<mssp aynh Ws t.yIl ee=t\u0022s Ef\u2019odn te-lfoacmriEl y,:a'r.aSrFr eNFS  fToe xetk'u;D\u0022 >eThhto ufgoh  ttsheihse bt reehats utrae dy lmaatpI  nootw  liasg ustarfoePl ym oprrfe sdeerlvgegdu misn  nteheeb  ceovlalhe cytliloann iogfi rtoh eo tB idbelrioomtuerc as aEws teerneshep siinn aMlopd eonnai,t ntahCe ",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "326",
            "y": "578"
        },
        "marker-label": "2",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>y/l er=b\u0022< >m\u0022a;r'gtixne-Tt oSpN: 0FpSx.;' :myalrigmianf--btontotfo m;:x0pp0x:;t nmeadrngii-nt-xleetf t;:00:ptxn;e dmnair-gkicno-lrbi-gthqt-: 0;pxxp;0 :-tqhtg-ibrl-oncikg-rianmd e;nxtp:00:;t fteelx-tn-iignrdaemn t;:x0pp0x:;m\u0022o>t<tsopba-nn isgtryalme =;\u0022x pf0o:npto-tf-anmiiglrya:m' .;SyFt pNmSe :Teepxytt'-;h\u0022p>aLregaarrnaipn-gt qb-y\u0022 =Lealtyittsu dpe<< />spp/a<n>>n<a/pps>/ <<.pt nsetnyilten=o\u0022c- qnta-cpiarrfaAg reahpth -ftoy pree:tenmepct ye;h tm arrageinn -tteomp :t0aphxt;  pmaamr geihnt- bnoot tdoems:o0ppmxi;r empaursg isne-llcerfitc: 0opwxt;  emhatr ghignu-orrihgth tn:w0ophxs;  s-iq th-cbilhowc k,-mientdseynst :e0n;i lt ebxmtu-hirn dae nsti: 0eprxe;h  ftonnetd-ifvaem iolsyl:A' ..S)Fe dNuSt iTteaxlt 'f;o\u0022 >s<ebnri l/ >g<n/ips>u  <dpe tsateyrlce =e\u0022r emwa rygeihnt- tsoap(: 0epsxi;c emrapr goisn -ebroat t,oeml:p0mpaxx;e  mraorfg i,na-clierfftA: 0nprxe;h tmraorng ifno- rsitgshato:c0 pexh;t  -yqhtw- bslnoocska-eirn deehntt :f0o;  ttreaxpt -sipnadhernetp: 0spix ;s\u0022i>h<Ts p.arno isrtpy lyer=u\u0022t nfeocn ta- fyatmiirlayl:u'p.oSpF  oNtSn iT eexmto'c; \u0022y>lTnhoi sd athy phec iohfw  m,anpo iitsa gkinvoawnn  laasc iam olnaotrittsuad ef oc heasrut ,e hwth ihcthi wm edaentsa niitg iwraos  ddaehs isgenneidl  teos erheTf l.escetd utthiet agll oebhet  aysb  ddeefni",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "226",
            "y": "1818"
        },
        "marker-label": "3",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>y/l er=b\u0022< >m\u0022a;r'gtixne-Tt oSpN: 0FpSx.;' :myalrigmianf--btontotfo m;:x0pp0x:;t nmeadrngii-nt-xleetf t;:00:ptxn;e dmnair-gkicno-lrbi-gthqt-: 0;pxxp;0 :-tqhtg-ibrl-oncikg-rianmd e;nxtp:00:;t fteelx-tn-iignrdaemn t;:x0pp0x:;m\u0022o>t<tsopba-nn isgtryalme =;\u0022x pf0o:npto-tf-anmiiglrya:m' .;SyFt pNmSe :Teepxytt'-;h\u0022p>aTrhgea rParpe-steqn-c\u0022e= eolfy tBsr apz<i l><p//s<p>anna>p<s//p<>  .<ypr usttnyelce =h\u0022t-6q1t -ephatr afgor agpnhi-ntnyipgee:be mephtty ;t am asregrionh-st onpa:c0iprxe;m Am ahrtguionS- boott tdoemd:a0ephx ;o hmwa r,glianr-blaeCf tz:e0rpaxv;l Am aorrgdienP- rfiog hhtc:r0apexs;e r- qeth-tb lootc ks-kinnadhetn t,:g0n;i ptpeaxmt -siinhdte nnti: 0lpaxi;t nfeosnste- fdaemviolryp: 'd.aShF  eNsSe uTgeuxttr'o;P\u0022 >e<hbTr  ./a>c<i/rpe>m A< ph tsutoySl ef=o\u0022  tmsaarogci nn-rteotps:a0ep xg;n omlaar gdienn-ibfoetdt osma: 0,plxi;z amraBr gfion -slreufott:n0opcx ;e hmta rsgliane-vreirg htti: 0tpaxh;t  -tqcta-fb leohctk -siin dpeanmt :s0i;h tt etxuto-bian dtennatc:i0fpixn;g\u0022i>s< stpsaonm  sstpyalher=e\u0022P >f\u0022o;n'tt-xfeaTm iSlNy :F'S.",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "716",
            "y": "1719"
        },
        "marker-label": "4",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>y/l er=b\u0022< >m\u0022a;r'gtixne-Tt oSpN: 0FpSx.;' :myalrigmianf--btontotfo m;:x0pp0x:;t nmeadrngii-nt-xleetf t;:00:ptxn;e dmnair-gkicno-lrbi-gthqt-: 0;pxxp;0 :-tqhtg-ibrl-oncikg-rianmd e;nxtp:00:;t fteelx-tn-iignrdaemn t;:x0pp0x:;m\u0022o>t<tsopba-nn isgtryalme =;\u0022x pf0o:npto-tf-anmiiglrya:m' .;SyFt pNmSe :Teepxytt'-;h\u0022p>aFrlgoarriadpa-?t qO-r\u0022 =Meelxyitcso ?p<</ s>ppa/n<>><n/app>s /<<p. asdtiyrloel=F\u0022 -fqot -ppiatr aeghrta prho- toycpiex:eeMm pntiy ;a lmuasrngiinne-Pt onpa:t0apcxu;Y  meahrtg iynf-ibnogtitso mo:t0 pdxe;d nmeatrngii ns-il esfith:t0 prxe;h tmeahrwg ient-arbiegdh tl:l0iptxs;  s-rqatl-obhlcoSc k.-aibnudCe nfto: 0n;o itteaxttn-eisnedrepnetr: 0ephxt;  rfaoennt -tfuaom isltyu:j' .tSaFh tN Sn iTaerxrte't; \u0022n>e<ebrrg  /f>o< /bpa>l s< pl lsatmysl ea= \u0022r omfa regvians- t,oppa:m0 pexh;t  mmaorrgfi nt-nbeostbtao my:l0lpoxh;w  msamregeisn -alceifrte:m0Ap xh;t rmoaNr g.irne-nrriogch tt:f0eplx ;r e-pqptu- belhotc kn-ii nndeeenst :e0b;  ntaecx ts-iihntd efnot :e0lppxm;a\u0022x>e< sepmainr ps tAy l.ed=e\u0022t cfiopnetd- feabm iolty :s'a.wS Fs sNaSm dTneaxlt 't;a\u0022h>wW hginlien otihtisse umqa ps rwaoluolhdc sh aevvea hb elelni trse vtealhatt osrpya gf osru oIitraulci aenm onso beivlaietly  sieno dt htei  1,6ytrhu tcne",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "897",
            "y": "954"
        },
        "marker-label": "5",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};