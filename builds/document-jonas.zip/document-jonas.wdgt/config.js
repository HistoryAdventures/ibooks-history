var widgetconfig = {
    "background_picture": "7gbp4j8.c6d0e4f12_f0c06043f_cSd_",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "4409",
        "Height": "2209",
        "X": "-01",
        "Y": "-11"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n  .sttpyilrec=s\u0022e dm-anrogni ny-lteovpi:t0aplxe;r  mnairagmienr- b,oatntiohmC: 0fpox ;e nmialrtgsiano-cl etfsta:v0 pexh;t  mraor gaicni-rreimgAh th:t0rpoxN;  f-oq tt-sbaloocc kn-rientdseanet :e0h;t  tfeox te-sionhdte netk:i0lp x,;s\u0022r>eAh tSoi x;tneoeinstihc eCrepn tfuor yl eVvieelw  noifa ttrheec  Wao rtlcde<l/fsepra n,>a c<ipr esmtAy lhet=u\u0022o-Sq tr-eptasraaeg rdanpah -atcyipref:Ae mnprteyh;t rmoanr gfion -etsooph:t0 pexk;i lm a,rsgeinni-lbtostatoocm :e0mpoxs;  :meabroglign -elhetf td:n0upoxr;a  mdaaregripns- rdiaghh ts:n0opixt;a l-uqpto-pb lnoacekp-oirnudEe nrta:f0 ;w othe xtts-uijn dfeon te:s0npexs; \u0022a> <sbyre v/n>o<c/ py>l l<apc isftiycleep=s\u0022  tmIa r.gdioni-rteopp :e0hptx ;n im adregwieni-vb ostatwo md:l0rpoxw;  emhatr gwionh- lfeof tt:o0hpsxp;a nmsa rcgiitns-artingahft :a0 psxe;s a-cqwto-hbsl oycrku-tinnedce nhtt:n0e;e ttxeixst -yilnrdaeen te:h0tp xm;o\u0022r>fT heirse hpplsain",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "99",
            "y": "59"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tFprmoem: eRpiystk-yh pOarriggairnasp<-/tsqp-a\u0022n=>e l<ypt ss tpy<l e>=p\u0022/-<q t.-sptaarcaugdr adplho-gt yepvel:eewmtp tfyo;  mmuasr geihnt- tnoip :o0optx ;t im arrogfi ny-lbeomtotsodmn:a0hp xd;i ampa ryglidne-tlreofptr:u0pp xe;k umDa reghiTn -.ryiagdh ts:t0ip xf;o  -yqhtp-abrlgoocekg- ilnadbeonltg: 0d;e ttneexmtu-ciondd eynlte:v0ipsxn;e\u0022t>x<eb rt s/o>m< /eph>t  <fpo  setmyolse =d\u0022e smaacrwgoihns- tpoapm: 0spixh;t  mdanrag i,ne-bbooltgt oemh:t0 pfxo;  smaaerrgai nw-elne fgtn:i0tprxa;h cm aortg ienm-arci gthit :n0ephxw;  s-rqott-ibtleopcmko-ci nndaeenpto:r0u;E  treixeth-ti nfdoe ndta:e0hpax ;e\u0022r>eTwh oeusgehu gtuhtirso Pt reehats uerseuda cmeaBp  ?npoawm  ias  eslagfgeulmys  pyrheWs e.rIv eedt siEn\u2019 dt heel occorlEl e,catriaornr eoFf  ftoh ee kBuiDb leihott efcoa  tEssetheenbs ee hitn  tMao dyelnaat,I  tohte  lCaagnuttirnooP  pmloarnfi sdpehlegrgeu mwsa sn ereubm oerveadh  tyol loarniig",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "1347",
            "y": "508"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tLpemaer:neipnygt -bhyp aLragtairtaupd-et<q/-s\u0022p=aenl>y t<sp  ps<t y>lpe/=<\u0022 -.qttn-epnairtangorca pnha-ctiyrpfeA: eemhptt yf;o  mraertgnienc- teohpt: 0rpaxe;n  mtaermg itna-hbto tptaomm :e0hptx ;n om adregsionp-mlierfetp:u0sp xs;e lmcarrigci no-wrti gehhtt: 0hpgxu;o r-hqtt -nbwloohcsk -siin dhecnith:w0 ;, mteetxsty-si nedneinlt :b0mpuxh;r\u0022 >a< bsri  /e>r<e/hp >t n<epd isvtey loes=l\u0022A  m.a)regdiunt-ittoapl: 0fpox ;s emnairlg ignn-ibsout tdoemt:a0eprxc;  emraerwg iyne-hlte fsta:(0 pexs;i cmearrpg ions- reirgah t,:e0lppxm;a x-eq tr-obfl o,cakc-iirnfdAe nntr:e0h;t rtoenx tf-oi nsdtesnato:c0 pexh;t\u0022 >yThhwi ss ntoyspaee ro fe hmta pf oi st rkanpo wsnp aahsr eap  lsait istiuhdTe  .crhoairrtp,  ywrhuitcnhe cm eaa nyst iirta lwuapso pd eostingin eedm otco  yrlenfol edcath  thhcei hgwl o,bneo iatsa gdievfainn elda cbiym otnhoer tlsaat iftou deessu.  eThhte shet ilwi ndeest ahnaidg ior",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "1497",
            "y": "779"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tTphmee :Perpeyste-nhcpea rogfa rBarpa-ztiql-<\u0022/=seplaynt>s  <pp<  s>tpy/l<e =.\u0022y-rqutt-npeacr ahgtrnaepeht-xtiysp ee:hetm pftoy ;g nmianrngiigne-bt oeph:t0 ptxa;  smearroghisn -nbaoctitroemm:A0 phxt;u omSa rogti nd-eldeafeth: 0ophxw;  lmaarrbgaiCn -zreirgahvtl:A0 poxr;d e-Pq tf-ob lhoccrka-eisnedre neth:t0 ;o tt esxktn-aihntd e,ngtn:i0pppxa;m\u0022 >s<ibhrt  /n>i< /lpa>i t<npe ssstey ldee=v\u0022o rmpa rdgaihn -etsoepu:g0uptxr;o Pm aerhgTi n.-abcoitrteommA: 0hptxu;o Sm afrog itns-aloecf tn:r0eptxs;a em agrngoilna- rdiegnhitf:e0dp xs;a  -,qlti-zbalroBc kf-oi nsdreunott:n0o;c  teehxtt -silnadeevnetr: 0tpix ;t\u0022a>hPte rthcaapfs  emhots ts is ipganmi fsiichatn tt uaob",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "799",
            "y": "1349"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tFplmoer:iedpay?t -Ohrp aMregxaircaop?- t<q/-s\u0022p=aenl>y t<sp  ps<t y>lpe/=<\u0022 -.qatd-ipraorlaFg rfaop hp-itty peeh:te mrpot yo;c imxaerMg inni- taolpu:s0npixn;e Pm anragtianc-ubYo tethotm :y0fpixn;g imsa rogti nd-eldenfett:n0ip xs;i  msairhgti nr-erhitgehhtw: 0eptxa;b e-dq tl-lbiltosc ks-rianldoehnctS: 0.;a btueCx tf-oi nndoeintta:t0npexs;e\u0022r>p<ebrr  e/h>t< /rpa>e n< pt usot yslteu=j\u0022  tmaahrtg inni-atrorpe:t0 pnxe;e rmga rfgoi nb-ablost tlolma:m0sp xa;  rmoafr geivna-sl e,fpta:m0 pexh;t  mmaorrgfi nt-nreisgbhat :y0lplxo;h w- qstm-ebelso cakc-iirnedmeAn th:t0r;o Nt e.xrte-nirnodce nttf:e0lp xr;e\u0022p>pWuh ielhet  tnhii sn emeasp  ewbo unladc  hsaivhet  bfeoe ne lrpemvaexlea teomriyr pf oAr  .Idteatlciiapne dn oebbi loitt ys aiwn  stshaem dsniaxlt eteanhtwh  gcneinntouirtys,e uiqt  sdroaelso hlcesa veev asho mlel ictusr itoauhst  gsap",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "76",
            "y": "619"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};