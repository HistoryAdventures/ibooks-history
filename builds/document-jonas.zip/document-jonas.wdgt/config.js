var widgetconfig = {
    "background_picture": "fg0e8p2j7.b533b4015_54c200c1a_9S_",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "1805",
        "Height": "1647",
        "X": "-91",
        "Y": "-81"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. rsatWy lse\u2019=e\u0022n nmAa rngeienu-Qt ospa: 0npwxo;n km aorsglian -,b)o4t1t7o1m-:100p7x1;(  mnaorigsisne-clceufSt :h0spixn;a pmSa rfgoi nr-arWi gehhtt: 0npix ;y v-aqNt -lbalyoocRk -eihntd ennit :e0c;i vtreexst -rienidlernate: 0sp\u2019xd;r\u0022a>eBblkaccaklbBe amrodr\u2019fs  dIecroinpiscn iS hyilpe<k/islp atns>o m< ps aswt yelmea=n\u0022 -rqetH- p.asrnaogtr a0p0h2- tdyeplea:teomtp tdyn;a  mtaereglifn -st\u2019odpr:a0epbxk;c amlaBr gfion -lbeoststeovm :p0iphxs;g amlafr geihnt- lseafwt :e0gpnxe;v emRa rsg\u2019ienn-nrAi gnhete:u0Qp x.;d r-aqetb-kbclaolcBk -eitnadreinpt :d0e;m atfe xeth-ti nsdae nntw:o0npkx ;r\u0022e>t<tberb  /s>a<w/ pf>l e<spm isht yolhew= \u0022, hmcaaregTi nd-rtaowpd:E0 pfxo;  lmeasrsgeivn -dbeoitrtootms: 0ephxt;  smaawr geignn-elveefRt :s0\u2019pexn;n Am anregeiunQ- rfilgehstm:i0hp xo;h w- q,th-cbaleoTc kd-rianwddeEn tf:o0 ;l etsesxetv- idnediernott:s0 pexh;t\u0022 >sQauwe eeng nAenvneeR\u2019 s",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "368",
            "y": "244"
        },
        "marker-label": "1",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n  .sytcyalrei=p\u0022  rmoafr gdienr-atpoepr:p0 pexb;  omta rlgeisns-ebvo tethotm :d0eppxp;i umqaer-geirn -dlneaf t,:)0epuxq;i nmiatrrgaiMn -rroifg hdte:n0iptxs;e d- q,ts-ebvlaolcsk(- iongdreanct :s0t;i  tdeexdta-oilnfdfeon te:h0 ptxn;i\u0022o>pS hhicpi hOwr itgai n,ss<e/isdpnaIn >t s<epW  sethytl er=a\u0022e-nq td-eplairaasg rtaip hs-at y7p1e7:1e mnpit yp;i hmsa reghitn -etroupt:p0apcx ;o tm aerlgbian -sbaowt tdorma:e0bpkxc;a lmBa r.g3i1n7-1l enfit :t0rpoxp;  nmaacrigrienm-Ar ihgthuto:S0 pax ;n i- qdtl-obsl oscakw- ienhdse nlti:t0n;u  tpeixhts- ienvdaelnst :a0 psxa; \u0022e>c<ibvrr e/s> <o/tpn>i  <dpn as teydlreo=c\u0022n omCa ragLi nr-etho pd:e0bpbxu;d emra ryglilna-ubtontetvoem :s0apwx ;e hmSa r.gsienc-rloeff th:c0npexr;F  myabr geirnu-trpiagch ts:t0ip xe;r o-fqetb- b,ldorcokc-nionCd eenhtT: 0,;p ithesx tt-nianhdcernetm: 0ap xs;a\u0022 >dOerniogiitncanlulfy  tbsuriilft  yilne kBirli sttsoolm,  eEgnngelvaenRd ,s \u2019aernonuAn dn e1e7u1Q0 ,",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "326",
            "y": "578"
        },
        "marker-label": "2",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tCpamnen:oenpsy<t/-shppaanr>g a<rpa ps-ttyql-e\u0022==\u0022e-lqytt-sp apr<a g>rpa/p<h -.tdyrpaeo:be mnpot ys;n omnanragci nd-ettonpu:o0mp xh;c umsa r0g4i ny-lbroatetno me:v0aphx ;o tm adregtirno-plreufpt :s0apwx ;e gmnaervgeiRn -sr\u2019iegnhntA: 0npexe;u Q- qst\u2019-dbrlaoecbkk-cianldBe nttu:b0 ;, stneoxntn-aicn ddeenttn:u0opmx ;f\u0022o> <lburf d/n>a<h/ pa>  t<spa eslt ytlae =d\u0022a hm asrpgiihns- teotpa:r0ippx ;t smoaMr g.imni-ab odtotoogm :y0lpexv;i tmaalregri nh-tliewf ts:a0epsx ;h gmiahr geihnt- rniog httc:a0ppmxi;  e-cqnta-tbsliodc-kg-nionld eendti:v0o;r pt edxltu-oicn dhecnith:w0 p,xn;o\u0022n>nTahce  dmeotsntu oems seehntt isaalw  wsepaiphosn  eftoarr ip",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "226",
            "y": "1818"
        },
        "marker-label": "3",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. esmtiytl ee=h\u0022t  mtaar gaiens- teohpt: 0npox ;s pmiahrsg itns-ebtostatfo me:h0tp xf;o  meanrog isna- lnewfotn:k0 psxa;w  mhacrighiwn -,reitgahgti:r0fp xa;  s-aqwt -ebglnoecvke-Ri nsd\u2019eenntn:A0 ;n eteeuxQt -eihntd e:nktc:u0lp xn;i\u0022 >sSatwr eeaHm l.i)neecdn eDrersuicgcno< /nsopmamno>c  <ap  ssatwy lsel=e\u0022s-sqetv- praerhatgor adpnha- tyyvpaeN: eemhptt yg;n imnanrugritnu-ot ospa:(0 paxe;s  meahrtg inno- bdoetetposm :e0eptxn;a rmaaurgg iont- ltenfeti:c0ipfxf;e  mdanrag idne-nriilgmhate:r0tpsx ;e b- qott- bdleodceke-ni nodselnat :p0i;h st edxetv-oilnedbe nst\u2019:d0rpaxe;b\u0022k>c<ablrB  /,>r<e/vpe>w o<hp  ,sstnyolnen=a\u0022c  mhatrigwi nd-etkocpo:t0sp xg;n imeabr goitn -nbooitttiodmd:a0 pnxI;> \u0022m;axrpg0i:nt-nleedfnti:-0tpxxe;t  m;a0r:gtinne-drniig-hktc:o0lpbx-;t q-",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "616",
            "y": "1719"
        },
        "marker-label": "4",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n  .sntiyaltep=a\u0022c  msatrig idnn-at oppi:h0sp xs;i hmta rfgoi ny-rboottst oemh:t0 pfxo;  emraormg ilnl-elte fott: 0dpexr;e vmoacrngui nn-ereibg hetv:a0hp xs;t c-aqfti-tbrlao cykn-aimn dteunbt :,0g;n itoegxnto- isnid ehnctr:a0epsxe;R\u0022 >.Rpuinhnsi negh tA gfroo usnndi aamnedr  Ldenguaocfy  d<a/hs pyaenh>t  <tpa hstt yrleet=a\u0022w-rqetd-npua rsaegurlacp hd-ntuyopfe :tesmrpitfy ;s tmsairggoilno-etaohpc:r0ap xn;e hmwa r,gsi0n9-9b1o tethotm :l0iptxn;u  msaervgaiwn -elhetf th:t0apexn;e bm adregrienv-orcisgihdtn:u0 pdxe;n i-aqmte-rb leogcnke-vienRd esn\u2019te:n0n;A  tneexetu-Qi n-d eyncta:r0ippx ;o\u0022t> <dbern r/u>t<e/rp >y l<ept asitdyelmem=i\u0022  nmeahrtg itnu-bt odpe:r0epdxn;e rmraursg ienh- b-o tettoamr:i0pp xa;  smaa rrgeienr-alce fst\u2019:d0rpaxe;b kmcaarlgBi nf-or idgnhet :e0hptx ;t o-nq ts-abwl otcakh-ti nhdgeunoth:T0 ;. atneixlto-rianCd ehnttr:o0Np xf;o\u0022 >tBseatowce eenh t1 7f1f7o  adnndu o1r7g1a8 ,r eBhl ancakrb edarrade btkecrarloBr inzeehdw  t,h8e1 7e1a setneurJn  ysleraabeo anrid  donfe  tnhae  oUtn ietmeadc  Setganteevse,R  bsu\u2019te ntnhAe  nreeeiugQn  fo",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "797",
            "y": "954"
        },
        "marker-label": "5",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};