var widgetconfig = {
    "background_picture": "8g4ndp5.b85264f_1442b0511_eS0_0",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "",
        "Height": "",
        "X": "",
        "Y": ""
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. dsltryolWe =w\u0022e Nm aerhgti nn-it orpe:w0oppx ;f om aersgiicnr-ebxoet teohmt: 0dpnxa;  hmtairagfi nn-eleewftte:b0 ppxi;h smnaorigtianl-erri gehsto:l0cp xe;h t- qrta-ebllco cske-kianmd eyntti:n0a;i ttseixrth-Ci nedceanrtb:m0ep xo;t\u0022 >s1s<e/nsgpnainl>l i<wp  rsiteyhlte =f\u0022o  mnaorigsiunl-ctnoip :e0hpTx ;. smraersgiinno-lbooct tloemu:r0cp xd;n am ayrzgailn -,lseufoti:c0appxa;r  meahrtg ihnt-irwi gdhets:o0ppaxt;x u-jq te-rbal oscuko-iirntdseundtn:i0 ;d ntae x,tt-sienndoehn t,:e0lpbxa;i\u0022m>aW rsiat tdeeny aarst rao pp o,leelmpioceapl  ethrTa c.ty,t etioc ocso nevviintcaen  tfhoe  nSopiatnaitsnhe sCerropwenr  ocfi ltlhyed in enead  etdoi vaocrtpi oont  teor ephr onteeecst  etbh en aicn dsiagseanCo ussa lp o,psunloait",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "158",
            "Y": "63"
        },
        "point": {
            "x": "1847",
            "y": "897"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n  .sstryelhet=o\u0022  ymnaarmg idnn-at ospd:n0aplxs;i  measreghitn -nboo tyttoemi:c0opsx ;e vmiatragni nf-ol enfoti:t0cpuxr;t smeadr geihnt- rriogfh te:l0bpixs;n o-pqste-rb lsoacwk -yicnndeegnat :n0a;m uthe xtta-hitn dreenftn:i0 poxt; \u0022e>r2e<h/ snpeaens>  e<bp  nsatcy lsea=s\u0022a Cm asragLi n,-stnoapc:i0rpexm;A  meavrigtiann- bfoot troeml:l0ipkx ;t smeatrageirng- leehftt :s0apwx ;e smaaersgiidn -hrgiugohhtt:l0ap xd;n a- q,te-cbnleolcoki-vi nodte netc:n0e;r etfeexrt -ciinfdiecnetp:s0 poxn; \u0022s>eHkearme ,e hL ahsg uCoahstalsA  c.anno ibtec usretesne dt or iperhets ennit  ttuob  t,hneo iCtraolwunp otpheed  treirerhitb lnei  dyelmnoog rtaopnh iecc nceotlsliaspnsie  soifh  tshie  ,isnpdaihgreenpo uesl bpaotpounl aetriooMn s. nioni ttahsei nNoelwo cW ofrol ds.t cHeifsf er eefhetr eynbc et htgou otrhwe  s3a0  nootihtecru ritssleadn dfso  adraoeurnpds  Seahnt  Jdunaan  ,(yPtueeirctoos  Reivciot)a nm afkoe  yctliexaerl ptmhoec ",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "1847",
            "y": "1967"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. ssatcyilree=m\u0022A  meahrtg iont-ntio pn:o0ipsxn;a pmxaer gliani-rbeoptmtio mh:s0ipnxa;p Sm anrig irno-tlceafft :g0npixt;a vmiatrogmi nl-ariicguhrtc: 0ap xd;e y-aqltp- btlaohctk -,imnsdielnitt:n0a;c rteemx tf-oi nedlepnitc:n0iprxp; \u0022e>h3t< /,shptalna>e w< pl asitryeltea=m\u0022  fmoa rngoiint-ctaorpt:x0ep xe;h tm asragwi nt-Ib o.tetlobma:t0opnx ;s im adrlgoign -rloeff td:e0eprxg;  am adregiifni-creipgsh ts:a0hp xe;h  -tqath-Tb l.osceki-nionldoecn tn:a0c;i rteemxAt -riinedhetn tn:i0 psxe;m\u0022i>rLca sh sCiansaapsS\u2019  oatc cdoeutnutb iorft ntohce  saathr odceietrige sw oohf  ytlhtei cSiplapnxies hs eibni rtchsee dN eewr eWho rslads afCe ds adLi rceicltolhyt aiCn ttou obvreoda dae rh gEuuorhotpleAa>n/  prrbe<j>u/d ircbe<s  .cnoonictearmnrionfge Rt heeh tg rdeneidh eabn ds ercanpaavceiitryg  olfa rbtontehc  tehhet  nfeow  einmop esraiwa lhitsltase wa nsd\u2019 hocfr uthhCe  cCialtohhotlaiCc  eChhtu r,clhl aw hroemt ftAh e.yd ertenperse",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "444",
            "Y": "51"
        },
        "point": {
            "x": "2975",
            "y": "290"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. \u2019sstayslaeC= \u0022s amLa rsgai nh-ctuosp :s0gpnxi;t imrawr gyibn -dbeortitposmn:i0 pyxl;t nmeaurqgeirnf- lseafwt :d0npax ;, emraurtgainn -nrii gchitl:o0hptxa;C --iqttn-ab ldoncak -hisnidneanptS:-0i;t ntae xytl-ticnndietnsti:d0 psxa;w\u0022 >k4r<o/ws ptanne>u q<eps bsutsy lsei=H\u0022  .myarrugtinne-ct ohpt:601p xe;t amla reghitn -nbio tntooimt:i0spixu;q nmIa rhgsiinn-alpeSf te:h0tp xf;o  msanrogiisns-erripgehrt :e0hptx ;g n-iqrtu-db lsodcnka-lirnedhetnetN: 0e;h tt eexetl-fi nodte ndte:c0rpoxf; \u0022s>tCsriatfrtae dh swiimtmhe laFn  ae y,ey roBn  eidt sr ordhoeethoTr ifcoa ls ginmiphacctte,  eLhats  eCraas aesl\u2019p mdaexsec reilpbtaitoonns  Ao f. htshien aNpaSt icvielso hatnadC  oefh tt htes nSipaagnai sshe lagrgeu rntost adbeluen iftonro ct hreiierh ts teatrakd icloanvt roats td.e cAusd osrepe n, saebtoavtes,  ttnhaet sneattoirvPe sn ia ryel lfaruesquu e,nstklryo witdryal lciicf iarnrdo hp adceirfiipcs npie oeprleehs .s aBsya Cc osnatLr afsot ,e shoehrte  sdae shccruisb isnngo itthpei rScpsaendi s,hs eaitr uwtonrekc  ohnt 7t1h ed nias lhatn6d1  oefh tH insip aenriaoflraa w( tlhaet uGrrbe aottenri  Arnetviol ldeesl,l iip.se .s etthaet sD onmaienpiocraunE  Rneepeuwbtleibc  n/o iHtaiitteip)m,o ch issA  d.edsncergiepLt ikocnasl Bc odmeel laalci-voes  weihtth  ostc edneetsu boifr tanlomco sdtn au nniomiatgainniagbalmei  cnraueeplotryu.E  Hree diaso rabg aeihnt  koetenni  tdoe fs tsrneosist ptihracts etdh ecsieh paarreg  chrciumSe>s\u0022 ;cxopm0m:ittnteeddn ib-yt xCehtr i;s0t:itannesd,n id-ekscioglnbe-dt qt-o  ;sxhpo0c:kt hhgiisr -cnoingtreammp o;rxapr0y: trfeeald-enrisg rianmt o; xapc0t:imoont.t o<b/-pn>i g<rpa ms t;yxlpe0=:\u0022p omta-rngi",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "403",
            "Y": "196"
        },
        "point": {
            "x": "2975",
            "y": "1015"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n  .setryilpem=E\u0022  omta rhgciano-rtpoppa: 0rpixe;h tm aerggnianh-cb oottt oymt:e0ipcxo;s  mhasrignianp-Sl enfith:t0ipwx ;s tmnaermgeivno-mr iegrhetw: 0eprxe;h t- qtta-hbtl oectka-ciinddnein ts:e0o;d  tsewxatl- ihncduesn tf:o0 pnxo;i\u0022t>a5g<l/usmpoarnp>  e<hpt  s,tdyelsei=l\u0022a tmuarrbg idnn-at o,pd:e0tpaxe;r tmlaarmg i,nd-ebtoitotlopmx:e0 pexb;  omta rdgeiunn-iltenfotc: 0spexv;i tmaanr geihnt- rdingah t,:d0eptxt;i m-mqotc- belbo cokt- idneduennitt:n0o;c  tseexmti-ricn dhegnuto:h0tplxA; \u0022.>sTeoiwnaorldosc  thhsei neanpdS  oefh th insi  tsrneaactiirseem,A  Leavsi tCaans afso  ryeraefvfailrsm se htth adte hhsiisl owboar kh ciish wd i,r2e4c5t1e df ot os wtahLe  wSepNa neihsth  oCtr oswrne,f ewrh ooms loas tseanssaiCb lsya Lc o.netlrboilslseodp mtih eh gcionl olnoiretsn o(ct heev irtecaelfiftey  ewdaasm  fyrteiqruoehnttulay  ltahrattn eicn  ethhti sd neaa rylnyo lmoocd eerhnt  enmepeiwrtee,b  tsheec nvaatssti d",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "649",
            "Y": "2"
        },
        "point": {
            "x": "774",
            "y": "46"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};