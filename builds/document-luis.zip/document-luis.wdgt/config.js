var widgetconfig = {
    "background_picture": "8g4ndp5.b85264f_1442b0511_eS0_0",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
       "Width": "4606",
        "Height": "2429",
        "X": "29",
        "Y": "27"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.adrlgrionW- twoepN: 0ephxt;  nmia rrgeiwno-pb oftot oems:i0cprxe;x em aerhgti nd-nlae fhtt:i0apfx ;n emeawrtgeibn -priihgshnto:i0tpaxl;e r- qets-obllco cekh-ti nrdaeenltc: 0s;e ktaemx ty-tiinndaeintts:i0rphxC; \u0022e>c<asrpbamne  sotty lses=e\u0022n gfnoinltl-ifwa mriileyh:t' .fSoF  nNoSi sTuelxctn'i; \u0022e>hWTr i.tstreenz ianso lao cp olleeumricc adln at ryazcatl,  ,tsou ociocnavpianrc ee htth eh tSipwa ndiessho pCartoxwunj  oefr at h,es unoeierdt stuod npir odtneac t, ttsheen oihn d,ieglebnaoiumsa  psoap udleaytairotnrso,p  L,aesl pCoaespa se hcTa n. ybtee isceoesn  ehveirtea nt of op rnooviitdaet naens eirdpyelrl ic",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "158",
            "Y": "63"
        },
        "point": {
            "x": "1847",
            "y": "897"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m a.rsgrienh-ttoo py:n0apmx ;d nmaa rsgdinna-lbsoit teosme:h0tp xn;o  myatregiicno-sl eefvti:t0apnx ;f om anrogiitnc-urritgshetd: 0ephxt;  r-oqft -ebllboicskn-oipnsdeern ts:a0w;  ytcenxetg-ai nndaemnuth: 0tpaxh;t\u0022 >r<esfpnain  ostt yelree=h\u0022  nfeoenst -efba mnialcy :s'a.sSaFC  NsSa LT e,xstn'a;c\u0022i>rHeemrAe ,e vLiatsa nC afsoa sr eclalni kb et sseeteane rtgo  ephrte sseanwt  etsoa etshied  Chrgouwonh ttlhae  dtnear r,iebclnee ldoeimvo gorta pehcince rceoflelra pcsief iocfe ptsh eo ni nsdeikgaemn oeuhs  hpgoupouhltaltAi o.nnso iitnc utrhtes eNde wr iWeohrtl dn.i  Htiusb  r,enfoeirteanlcuep otpoe dt hrei e3h0t  ontih eyrl nios ltaonnd se canreotusnids nSia ns iJhu asni  (,Psupearhtroe pR ieclob)a tmoank ee rcolMe a.rn otihtea zcionmoplloecx iftoy  sotfc enfaftei veeh ts oycbi etthyg,u oarnwd  stah en osiptrceuardt soefd ",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "50",
            "Y": "50"
        },
        "point": {
            "x": "1847",
            "y": "1967"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.asragciinr-etmoAp :e0hptx ;o tmnair gnioni-sbnoatptxoem :l0apixr;e pmmair ghisni-nlaepfSt :n0ip xr;o tmcaarfg ignn-irtiagvhitt:o0mp xl;a i-cqutr-cb lao cdke-yianldpe ntta:h0t;  ,tmesxitl-iitnndaecnrte:m0 pfxo; \u0022e>l<psipcanni rspt yelhet= \u0022, hftolnate-wf almaiilrye:t'a.mS Ff oN Sn oTietxcta'r;t\u0022x>eL aesh tC assaaws \u2019t Ia c.ceolubnatt oonf  stih ed laotgr orcoift ideese rogf  at hdee iSfpiacneipssh  sianh  tehhe  tNaehwT  W.osrelidn ofleodc  dniarceicrtelmyA  irniteoh tb rnoia dseerm iErucr ohpseianna ppSr eojtu ddiecteusb icrotnncoecr nsianhg  dteheer gg rweoehd  yalntdi crialppaxcei tsye boifr cbsoetdh  etrheeh  nseaws aiCm psearLi acliilsothst aaCn d, toufo vtehde  aC ahtghuoolhitcl AC>h/u rrcbh< >w/h ormb <t h.enyo irteapmrreosfeenRt eedh.t  Adfntiehre ba lsle,c ntahvee iCragt hloalritcn eCch uerhcth \u2019fso  weenaol tsha w",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "444",
            "Y": "51"
        },
        "point": {
            "x": "2975",
            "y": "290"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.a\u2019rsgaisna-Ct ospa:L0 psxa;  hmcaursg isng-nbiottitrowm :y0bp xd;e rmiaprsgniin -ylletfnte:u0qpexr;f  msaarwg idnn-ar i,gehrtu:t0apnx ;n i- qcti-lbolhotcakC--iintdnean td:n0a;  htseixnta-piSn-dietnnta: 0yplxt;c\u0022n>i<tsspiadn  ssatwy lker=o\u0022w  ftonnetu-qfeasmbiulsy :s'i.HS F. yNrSu tTneexct 'h;t\u00226>1C reatfatle de hwti tnhi  anno ietyies iounq niIt sh srihneatpoSr iechatl  fiom psancoti,s sLearsp eCra seahst\u2019  gdneisrcurdi pstdinoanlsr eohft etNh ee hNta teievlefs  oatn dd eocfr otfh et sSiptarnai shhs iamrmee lnFo taa b,lyer Bf oerd  trhoediore hsTt afrok  scgonnithrcatset .e hAts  ssie eenl pambaoxvee ,e ltbhaet onna tAi v.ehss ianraep Sf rceiqluoehnttalCy  eihdty ltlsinci aagnad  spealcgigfuirct sp edoepulnei.t nBoyc  croinethrta sett,a dhielraev  doets cdreicbuidnogr pt h,es eStpaatnsi sthn aatts ewtoorrkP  onni  tyhlel aiusslua n,ds korfo wHtirsap acniifoilrar o(ht hdee rGirpesantie re rAenht islalseasC,  sia.Le .f ot hees oDhotm isnai chacnu sR espnuobiltipci r/c sHeadi t,is)e,i rhuitsn edce shctr7i1p tdinoan sh tc6o1m ee hatl invie  ewriatfhr aswc elnaetsu robf  oatlnmio srte vuon idmealgliinpasb lsee tcartuse lntaye.p oHreu Ei sn eaegwatienb  kneoeint ittoe psmtorce sssA  t.hdante gtehLe skec aalrBe  dcerlilmaecs- ocso memhitt toetd  dbeyt uCbhirritsntoica ndsn,a  dneosiitganneidg atmoi  snhaoecpko rhuiEs  rceodnatoermbp oerhatr yo trneia ddeerfs  sinnotiot paicrtcisoend. <c/ishppaanr>g< /hpc>u S<>p\u0022 ;s'ttyxleeT= \u0022S-Nq tF-Sp.a'r:ayglriampahf--ttynpoef: e\u0022m=petlyy;t sm anragpisn<->t\u0022o;px:p00p:xt;n emdanrig-itnx-ebto t;t0o:mt:n0epdxn;i -mkacroglibn--tlqe-f t;:x0pp0x:;t hmgairrg-inni-grriagmh t;:x0pp0x:;t f-eqlt--nbilgorcakm- i;nxdpe0n:tm:o0t;t otbe-xnti-girnadme n;tx:p00p:xp;o tf-onnitg-rfaamm i\u0022l=ye:l'y.tSsF  pN<S  >Tpe/x<t>'/; \u0022r>b<",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "403",
            "Y": "196"
        },
        "point": {
            "x": "2975",
            "y": "1015"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m a.regriinp-mtEo po:t0 phxc;a omraprpgai nr-ibeohttt oemg:n0aphxc;  omta rygtieni-cloesf th:s0ipnxa;p Sm anrighitni-wr isgthnte:m0epvxo;m  -eqrte-wb leorcekh-ti ntdaehntt :e0t;a ctiedxnti- isnedoedn ts:w0aplx ;h\u0022c>u<ss pfaon  nsotiytlaeg=l\u0022u mfoornpt -efhatm i,ldye:z'i.lSaFt uNrSb  Tdenxat ',;d\u0022e>tTaoewratrldasm  t,hdee teinodl poxfe  heibs  ottr edaetuinsiet,n oLca ss eCvaistaasn  reehatf fdinram s, dtehtatti mhmiosc  weobr ko ti sd eduinrietcntoecd  steom itrhce  hSgpuaonhitslhA  C.rsoewinn,o lwohco mh soisntaepnSs iebhlty  ncio nstnraoclilreedm At heev ictoalno nfioe sy r(etvhael sr eeahlti tdye hwsaisl ofbrae qhuceinhtwl y, 2t4h5a1t  fion  stwhaiLs  weeaNr leyh tm oodte rsnr eefmepri roes,l at hsea svaaCs ts adLi s.tealnbciesss obpemtiw ehegni nt hleo rctonloocn ye vaintdc etfhfee  ceednatmr aylt iaruoth",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "649",
            "Y": "2"
        },
        "point": {
            "x": "4009",
            "y": "797"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};