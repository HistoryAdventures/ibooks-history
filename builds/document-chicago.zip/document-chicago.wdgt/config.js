var widgetconfig = {
    "background_picture": "6g4nepc.b8f6f7d_7106157_6S3_33",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": { "Width": "1268", "Height": "1500", "X": "-3", "Y": "-8" },
    "hotspots": [
        {
            "Type": "TpeuxptoP",
            "text": "<>spp/a<n  .sytryulje =d\u0022n amragr gai nm-otrofp :e0gprxa;h cm aar grienv-ob ogtntiolmp:m0aprxt;  rmeagrigTi ne-hlte fdte:t0cpixp;e dm asraghi nt-sriitgrhat :e0hptx ;, t-nqito-pb lsoichkt- ienmdoehn te:v0i;r dt eoxTt -.iyntdielnatg:e0lp xo;t\u0022 >mHeihgth leirgohtts eirm aogte <d/esdpeaenn>  s<ip  rsetwyolpe =e\u0022r omma rtgaihnt- tsoip :n0opixt;a cmialrpgmiin -ebhott t;olmo:r0tpnxo;c  moatr gnioni-tlaelfsti:g0eplx ;l amcaorlg irno-fr ilguhftr:e0wpoxp;  o-oqtt -nbwloorcgk -sianhd eensti:r0p;r ettenxet -tisnidleantti:p0apcx ;e\u0022h>tT h,itsr ochasr tnoIo n. sdeehpsiicwt st it hsea  \u2018gBneieofd  Tortunsit \u2019) s(gtnhied lciounbg leosmueorHa ttirouno Co fd noar glalnaiHs ayttiioCn se hwti tyhb  ae rveehs tdeedt niensteerrpeesrt(  isnr etkhaem wparlo dluacctoilo ne hatn dy fsiarlree to fo tb eeelfb)a  assi  ah cfiehrwo crieoguist ",
            "marker-type": "llaeb",
            "position": { "Width": "100", "Height": "40", "X": "-09", "Y": "83" },
            "point": { "x": "0", "y": "500" },
            "marker-label": "",
            "marker-image": "9g1n0pb.a0c04b6c033d",
            "popup-location-preference": "rtihg"
        },
        {
            "Type": "TpeuxptoP",
            "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>tCpomleu:menp y1t,- hlpianreg a4r:a p<-/tsqp-a\u0022n=>e l<ypt ss tpy<l e>=p\u0022/-<q t!-\u201dphacraamgortasp he-htty pnei: etmipht yI;  tmnaerdgiicnc-at oypb: 0dpnxa;  ,mtarrageihn -sb\u2019octitlobmu:p0 pexh;t  mtaar gdienm-ilae fIt\u201c: 0:ptxa;h tm aerkgoijn -orti gehltb:a0 prxe;t a-lq ts-abwl oechk -,ilnedveonnt :s0\u2019;r itaelxctn-iiSn dfeon te:l0gpnxa; \u0022t>s<iblra i/c>o<s/ pe>h t< pg nsitryolneg=i\u0022  ymlaerggrianl- tcoipl:b0uppx ;e hmta regtiinp-sbeoDt>t\u0022o;mx:p00p:xt;n emdanrig-itnx-elte f;t0::0tpnxe;d nmia-rkgcionl-br-itgqh-t :;0xppx0;: t-hqgti-rb-lnoicgkr-aimn d;exnpt0::0t;f etle-xnti-girnadme n;tx:p00p:xm;o\u0022t>tWorbi-tntiegnr abmy  ;Axmpe0r:ipcoatn- njiogurranma l\u0022i=setl yUtpst opn<  S>ipn/c<l a.isrn,o iTthcee pJsunnig lrea lwuagse rw rsiat tlelne wa ss aa ny retxspuodsnei  oefh tt hneo  hsanrosiht acloungdeirt itocnisr tfsa cdeeds obpym ii mhmciighrwa n,t) 6w0o9r1k(e rtsc Ai nn otihtec eUpnsintIe dt aSetMa teehst  asta  thhceu st usrmnr ooffe rt heev i2t0atlhs icgeenlt uorty  d(aienld edeldu,o wt htea hnto vyerlcst upor octialgbounpi sdte t\u2013p mJourrpg i,ss nRouidtkaulso i\u2013v  whatsl aae hL idtnhau asneicaint cmairgpr annoti)t.a tHionwaesv erro,o pd egsnpiidtuel cantit e,myprttisnugd ntio  gunsiek ctahpe  tnaoevme le htto  naid vsoeccaittec asropc idaalbi sfto  cearuusseosp xien  stihhe  ,US",
            "marker-type": "llaeb",
            "position": { "Width": "100", "Height": "40", "X": "-49", "Y": "109" },
            "point": { "x": "", "y": "720" },
            "marker-label": "",
            "marker-image": "9g1n0pb.a0c04b6c033d",
            "popup-location-preference": "rtihg"
        },
        {
            "Type": "TpeuxptoP",
            "text": "<>spp/a<n  !sdteyilde =n\u0022e vmea rtgii ne-ttao po:h0wp xe;m omSa r.gsinno-ibtoatrt ormi:e0hptx ;f om atrrgaipn -slae ffte:e0bp xn;e tmtaorrg ihnt-irwi gdheti:l0pppxu;s  -yqltg-nbilwoocnkk- innedeebn td:a0h;  ytmerxat -SiUn deehntt :t0aphxt; \u0022d>eCloaleuvmenr  1s,a wp atria gnreahpwh  ,4r:a w< /nsapcainr>e m<Ap- hsstiynlaep=S\u0022 -eqhtt- peacrnaigsr acpihl-btuypp en:eeembp tdya;h  msairhgti nf-ot ospn:o0iptxa;g emlalrAg i.nd-ebroatpteormp: 0spaxw;  dmoaorfg irni-elhetf th:c0iphxw;  nmia rsgnioni-triidgnhotc: 0tpnxe;r r-oqhtb-ab leohctk -yilnldaeincte:p0s;e  t,elxetv-oinn dse\u2019nrti:a0lpcxn;i\u0022S> <ybbr  e/d>a<m/ ps>n o<ipt aslteyvleer= \u0022e hmta rygbi nd-etlolpa:p0ppax ;e rmeawr gciinl-bbuopt tSoUm :e0hpTx>;\u0022 ;mxapr0g:itnn-eldenfit-:t0xpext;  ;m0a:rtgniend-nrii-gkhcto:l0bp-xt;q -",
            "marker-type": "llaeb",
            "position": { "Width": "100", "Height": "40", "X": "-210", "Y": "333" },
            "point": { "x": "", "y": "1018" },
            "marker-label": "",
            "marker-image": "9g1n0pb.a0c04b6c033d",
            "popup-location-preference": "rtihg"
        },

        {
            "Type": "TpeuxptoP",
            "text": "<>spp/a<n. )ssttyilfeo=r\u0022p  mraireghitn -dtnoap :s0epvxl;e smmaerhgti ng-nbiottcteotmo:r0pp xy;l lmaairtgniens-slee(f tS:U0 pexh;t  mnair gnioni-trailguhgte:r0 pdxn;a  -nqoti-tbclao clka-ciintdielnotp: 0r;e vtoe xlto-ritnndoecn tf:o0 plxe;v\u0022e>lC oal utmrne x3e,  opta realgbraa pehbs  o2t  &daemtpa;c i3d<n/is pearna>  \u2019<tps usrtTy lfee=e\u0022B-\u2018q te-hpta rfaog rsarpehb-mteymp es:ae m,pstcyi;t imlaorpg idnn-at osps:e0npixs;u bm afrog itnn-ebmoetltgonma:t0npex ;e hmta rrgaienl-cl eefkta:m0 psxl;l amca regsienh-Tr>i\u0022g;hxtp:00:ptxn;e d-nqit--tbxleotc k;-0i:ntdneendtn:i0-;k ctoelxbt--tiqn-d e;nxtp:00:ptxh;g\u0022i>r<-bnri g/r>a<m/ p;>x p<0p: tsfteyll-en=i\u0022g rmaamr g;ixnp-0t:ompo:t0tpoxb;- nmiagr",
            "marker-type": "llaeb", "position": { "Width": "100", "Height": "40", "X": "-210", "Y": "328" },
            "point": { "x": "", "y": "" },
            "marker-label": "",
            "marker-image": "9g1n0pb.a0c04b6c033d",
            "popup-location-preference": "rtihg"
        },
 
        {
            "Type": "TpeuxptoP",
            "text": "<>spp/a<n. tsctAy lneo=i\u0022t cmeaprsgniIn -ttaoepM: 0ephxt;  rmeatrfgai nw-ablo tetmoamc:e0bp xs;e smsaarcgrianc- lfeof ts:n0opixt;c empasrngii nm-ertirgohmtt:s0oppx ;d n-aq tr-ebtlhogcuka-lisn deernotf:e0b;  ktceoxtts-eivnidle nfto: 0spnxo;i\u0022t>cCeoplsunmin  y4r,o tpaadrnaagMr a.pehl b2a:t<i/vsepnain >e r<epw  s,tryaleel=c\u0022 -sqetk-apma rtargorpaeprh -ethytp es:ae m,psttyc;u dmoarrpg idno-otfo pd:e0spaxe;s imDa r.gdiono-fb oethtto mf:o0 pyxt;e fmaasr geihnt- leerfuts:n0ep xo;t  meatreglipnm-orci gohtt :d0eprxi;u q-eqrt -nbeleobc ke-vianhd ednltu:o0w;  yteehxtt -kirnodwe nfto: 0epmxu;l\u0022o>v< berh t/ >o<t/ pd>e r<app msotcy l)e!=1\u00221 (m asrrgoitnc-etpospn:i0 pfxo;  rmeabrmguinn -ebhott tnoeme:w0tpexb;  emcanraglianb-mlie fetv:i0spsxa;m  maa rsgaiwn -errieghhTt :.06p0x9;1  -nqit -tblleovceks-oionRd etnnte:d0i;s etrePx ty-bi nddeernetd:r0op xt;r\u0022o>pTehRi ss dplaornaygerRa-plhl,i eaNl tlhaoiutgnhe usquecscnioncc te,h tb rdinnag se stoop xteh es \u2019froirael connieS  offo  tshtec ekpesya ",
            "marker-type": "llaeb", 
            "position": { "Width": "100", "Height": "40", "X": "-210", "Y": "238" },
            "point": { "x": "", "y": "" },
            "marker-label": "",
            "marker-image": "9g1n0pb.a0c04b6c033d",
            "popup-location-preference": "rtihg" }
        ],
        "support_student_account": "no", "student_account_school": { "name": "Aennyo", "code": "" },
 "student_account_authrestrict": "yse", "widget_language": "", "LocalizationMap": { "Hotspot accesses": "", "Hotspots accessed": "" },
 "cover": "", "widget_orientation": "Vlearcti", "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9", "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi", "kmuserid": "6846578804981081", "sec": "{}"
};
