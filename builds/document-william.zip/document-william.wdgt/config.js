var widgetconfig = {
    "background_picture": "1gbn4p1.88b6870_10b716e_2Sf_94",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "799",
        "Height": "866",
        "X": "-09",
        "Y": "-24"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> nsatpysl/e<=.\u0022t nmeanrigmionr-pt oypl:l0apixc;o sm adrngai ny-hbtoltateowm :y0lplxa;c impayrtg ienr-elwe f\u2013t :n0epmx ;l lmaa r\u2013g ilni-crniugohct :e0hptx ;f o- qstr-ebblmoecMk -.iynndoelnotc: 0e;h tt enxit -tirnudoecn tt:s0ephxg;i\u0022h> 1e<h/ts psaan >d e<vpr esst yolsel=a\u0022  ymeahrTg i.nr-otnorpe:v0opgx ;d emtanrigoipnp-ab oytltloamy:o0rp xe;h tm agrngiitns-ilsesfat :w0opnx ;, nmoairtgairnt-sriingihmtd:a0 plxa;i n-oqlto-cb lfooc kn-oiintduetnitt:s0n;i  ttenxatt-rionpdmein tn:a0 pdxe;n\u0022i>a<msepra nl isctnyuloec= \u0022e hfTo n.t4-2f6a1m inliy :y'nFaapvmoorCi ta'i;n ifgornitV- seihzte :o1t2 pnte;v\u0022i>gI nd a1h6 4I0 ,s etmhaeJ  VginrigKi nrieat rGaohvce renhotr \u2019fso  Cnoouintcuillo swsaisd  aeshkte dg ntiow odlelcoifd e, yonno ltohCe  npwuonriCs ham eenmto caepbp rdoaphr iaaitnei gfroirV  asn\u2019 0A4f6r1i ceahnt  \u2013n Ik>n\u0022o;wtnp 2a1s: eJzoihsn- tPnuonfc h; '-t iwrhoov ahFa'd: yaltitmeamfp-ttendo ft o\u0022 =reulnyatwsa yn atpos <M>a\u0022r;yxlpa0n:dt.n eTdhneii-rt xveetr d;i0c:tt noend ntih-ek ccoalsbe-,t qs-h o;wxnp 0i:nt htghier -dnoicgurmaemn t; xbpe0l:otwf,e lw-onuilgdr ahma v;ex pp0r:omfootutnodb -inmipgarcatm  o;nx pt0h:ep orte-lnaitgiroanms h\u0022i=pe lbyettsw epe<n  >Epu/r<o>pnea,p sA/f<r i.csaa cainrde mtAh e",
        "marker-type": "llaeb",
        "position": {
            "Width": "",
            "Height": "",
            "X": "",
            "Y": ""
        },
        "point": {
            "x": "201",
            "y": "71"
        },
        "marker-label": "1",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "bmoott"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> nsatpysl/e<= \u0022. ymlaertgiinni-fteodpn:i0 ptxo;n  mtaurbg i,ny-abpo tttuoomh:t0ipwx ;, nmyawrGg ihng-ulHe frto:f0 pdxe;k rmoawr geihn -;rtingahvtr:e0sp xd;e r-uqttn-ebdlnoic kn-ai nsdae nytl:l0a;n itgeixrto- ihncdneunPt :n0hpoxJ; \u0022t>e2r<p/rseptanni>  o<tp  ssntayilreo=t\u0022s imha rdgeiln -staohp :s0iphxT;  .meavraglisn -ab ottotno m,:t0npaxv;r emsa rag isna- loetf td:e0rprxe;f emra ryglilna-criirgohgte:t0apcx ;s i- qnth-obJl otcakh-ti nedteonnt :,0r;e vteewxotH- i.nddeernrtu:c0npix ;s\u0022a>h< sepha n\u201d ssstoyll\u201ce =e\u0022h tf ornotf- feasmnielpym:o'cFearv onrii t,'s;e cfiolnptm-osciczae :s1i2hp td;n\u0022a> Innh otJh ilsl epsa roatg rdaepwho,l lsae veebr aelh  kteayh td edteatislesu qeemre regvea.h  Foitr sdte,t rtohpeerre  siis  nay wcGl ehagru Hs e.nfslee somfi ht hhec nluePg inshloaJt ifvoe  nhoiietraatrncehsieersp  oefh tc oslio neitaoln  sfooc ioestlyA.> \u0022H;utgph2 1G:weyzni,s -ftrnoomf  w;h'ot iJroohvna FP'u:nyclhi maanfd- ttnwoof  o\u0022t=heelryst sh anvaep sr<u>n\u0022 ;axwpa0y:,t nheadsn is-utbxmeitt t;e0d: tan epdentii-tkicoonl bt-ot qt-h e; xcpo0u:ntchigli.r -Tnhiigsr acmo u;nxcpi0l: tifne lt-unring rhaams  ;ixnpd0i:cmaottetdo bt-hnaitg rtahme  ;cxrpi0m:ep onte-endisg rtaom  b\u0022e= emlaydtes  kpn<o w>np /t<o> ntahpes /G<o.vyenronloorc  ienh ta  nlie tytteirr;o htthueay  eatraem intoltu  teh",
        "marker-type": "llaeb",
        "position": {
            "Width": "",
            "Height": "",
            "X": "",
            "Y": ""
        },
        "point": {
            "x": "-007",
            "y": "188"
        },
        "marker-label": "2",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. ssetoyrlgee=n\u0022  ymaawragniunr- tsoap :s0rpexh;t om adrngai nh-cbnoutPt onmh:o0Jp xn;o  mraareglicn -glneifetb: 0spixs;a hmpamreg ienh-tr ihgthitw: 0,pyxt;e i-cqots- bllaoicnko-lioncd efnot :s0t;n etmeexlte- ilnadiecnatr: 0gpnxi;y\u0022l>r3e<d/nsup aenh>t  <opt  sstay lsen=o\u0022i tmaacrigdinni- troape:l0cp xs;n imaatrngoicn -obsoltat ohmp:a0rpgxa;r ampa rsgiihnT->l\u0022e;fxtp:00:ptxn;e dmnair-gtixne-tr i;g0h:tt:n0epdxn;i --kqcto-lbbl-otcqk-- i;nxdpe0n:tt:h0g;i rt-enxitg-rianmd e;nxtp:00:ptxf;e\u0022l>-Hneirger,a mt h;ex pm0e:cmhoatntiosbm-sn iogfr acmo l;oxnpi0a:lp oatu-tnhiogrriatmy  \u0022a=reel yatgsa ipn<  m>apd/e< .esveiidteenitc.o sI tl ahianso lgorca nntie de bt hdel upoocw elro rftonro ca  dpnaar tnyo iotfa rmtesni ntiom dbae  tensetmanbrleivsohge df,o  psaeisds ebcyo rppu belhitc  wfoulnsd sw,o ht og nhiutnatc iddonwin  ,alnidc nrueocco veehrt  Jooth nd ePtutnicmhb uasn ds ahwi sn oaictciotmeppl iscueosi.v eArlps oe,h to fe cnnoitse  shyearde  5a2r ed ntuhoer ad anteeksa.t  Tshaeh  ensotiasbsliimsmhomce nsti hotf ",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "309",
            "Y": "216"
        },
        "point": {
            "x": "-007",
            "y": "388"
        },
        "marker-label": "3",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. ssrtayelye =3\u0022  fmoa rygnionl-otco pe:h0tp xo;t  meacrigvirne-sb oltatnoomi:t0ipdxd;a  mnaar gdinna- lhegfutH: 0optx ;e cmiavrrgeisn -sr\u2019irgahety: 0lpaxn;o i-tqitd-dbal oncak -fion dtennetm:h0s;i ntuepx te-hitn dsean tl:l0epwx ;s\u0022a> 4,<e/rsuptanne>d n<ip  fsot yelcei=v\u0022r emsa rrgiienh-tt ofpo: 0tpsxe;r  meahrtg itnu-ob oetvtroems: 0optx ;d emcanregtinne-sl eefrta: 0,psxn;a empaorrguiEn -,rniegmh te:s0ephxt;  f-oq th-tbolBo c.kh-siintdteonctS: 0s;i  t,eyxrto-gienrdGe nste:m0apJx ;,\u0022r>eThhteo  ceahptt utrsel iohfw  J,ohhcnt uPDu nscih  ,arnodt chiiVs  ,feenlol o;ws efcuigliptmiovcecsa  issi hr edcnoar dnehdo Ji nf ot hsinsi gpiarroa gerhatp he.r aT heet obnr uftoa loistlyA >o\u0022f; xcpo0l:otnnieadln is-otcxieett y; 0i:st nmeaddnei -cklceoalrb,- twqi-t h; xepa0c:ht hmgainr -sneingtreanmc e;dx pt0o: tbfee lf-lnoigggreadm,  ;rxepc0e:imvoitntgo b3-0n i\u201cgsrtarmi p;exsp\u201d0 :epaocth-;n iwgirtahm  t\u0022h=ee lryitssk  po<f  >ipn/f<e.cltaitoanf  \u2013e bn onte vteo  dmleunotci odnn as heorcekv easn de rbelwo osdt nleomshss i\u2013n uspu ch",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "471",
            "Y": "475"
        },
        "point": {
            "x": "-007",
            "y": "529"
        },
        "marker-label": "4",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. rsettyslaem= \u0022s imha rfgoi n\u2013- teofpi:l0 prxo;f  m\u2013a rygtirne-pboortpt oemh:t0 pwxo;n  msair geihn -,ltenfatv:r0epsx ;d emraurtgniend-nrii gnhat :r0epgxn;o l- qotN- b.lsoecikn-oilnodce nnta:c0i;r etmeAx th-tirnodNe neth:t0 pnxi; \u0022y>r5e<v/aslpsa nn>a c<ipr fsAt y,llea=g\u0022e lm afrog ienl-ptmoapx:e0 pnxw;o nmka rtgsirni-fb oethtto ms:t0npexs;e rmpaerrg ihnc-nluePf tn:h0opJx ;. tmnaermguicno-dr isgihhtt: 0fpox ;e c-nqatc-ibflioncgki-si neduerntt :e0h;t  tseix ts-iihnTd>e\u0022n;tx:p00p:xt;n\u0022e>dUnnil-itkxee th i;s0 :ftenleldonwi -\u2013k cEoulrbo-pteqa-n  ;\u2013x pr0u:ntahwgaiyrs-,n iJgorhanm  P;uxnpc0h: twfaesl -sneingtreanmc e;dx pt0o: mao tmtuocbh- nwiogrrsaem  f;axtpe0.: pHoet -insi gorradme r\u0022e=de lhyetrse  pt<o  >spe/r<v e. )hdiest smeavsntie re rfeowr  stthreu orce slta ionfo lhoics  ensaethutr ahlc ilhiwf eh.t iMwo ryetoivreorh,t utAh ilsa ypouRn ieshhtm efnot  niosi tnaocti dlniim intae(d  etroe hVwiyrrgeivnei ao,t  bduetd neext",
        "marker-type": "llaeb",
        "position": {
            "Width": "21",
            "Height": "14",
            "X": "306",
            "Y": "784"
        },
        "point": {
            "x": "-007",
            "y": "699"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "tpo"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};