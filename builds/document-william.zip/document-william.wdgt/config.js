var widgetconfig = {
    "background_picture": "1gbn4p1.80b080031_b010e023f_9S4_",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "2606",
        "Height": "2110",
        "X": "-31",
        "Y": "-24"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.atrngeinni-mtoorpp: 0yplxl;a imcaorsg idnn-ab oythttolma:e0wp xy;l lmaacrigpiynt- leerfetw: 0\u2013p xn;e mm alrlgai n\u2013- rliigchntu:o0cp xe;h t- qfto- bslroecbkm-eiMn d.eynnto:l0o;c  teehxtt -niin dternuto:c0 ptxs;e\u0022h>g<ishp aenh ts tsyal ed=e\u0022v rfeosn to-sflaam iyleyh:T' L.urcoindrae vGorga nddeet'n;i ofpopnat -yslilzaey:o1r2 peth;t\u0022 >gInni t1s6i4s0s,a  twhoen  V,inrogiitnairat sGionviemrdnao rl\u2019asi nCooluoncc iflo  wnaosi taustkietds ntio  tdneactirdoep moin  ntah ed epnuinaimsehrm elnitc naupopcr oephrTi a.t4e2 6f1o rn ia ny nAafprmiocCa na i\u2013n ikgnroiwVn  eahst  Jooth nn ePvuingc hd a-h  wIh os ehmaadJ  agtntieKm prteetdr athoc  reuhnt  afwoa yn otiot uMlaorsysliadn de.h tT hgeniirw ovlelrodfi c,ty noonl otCh en wcoarsCe ,a  sehmoowcne bi nd athh ea idnoicgurmieVn ts 0b4e6l1o we,h tw onuIl>d\u0022 ;htapv2e1 :perzoifso-utnndo fi m;p'aecdtn aornG  tahdei crueLl'a:tyiloinmsahfi-pt nboeft w\u0022e=eenl yEtusr onpaep,s <A>f\u0022r;ixcpa0 :atnnde dtnhie- tAxmeetr i;c0a:st.n<e/dsnpia-nk>c<o/lpb>- t<qp-  s;txypl0e:=t\u0022h-gqitr--pnairgargarma p;hx-pt0y:ptef:eelm-pntiyg;r amma r;gxipn0-:tmoopt:t0opbx-;n imgarragmi n;-xbpo0t:tpoomt:-0npixg;r amma r\u0022g=ienl-yltesf tp:<0 p>xp;/ <m>a/r gribn<->r\u0022i;gthpt2:10:pexz;i s--qttn-obfl o;c'ke-dinnadreGn ta:d0i;c utLe'x:ty-liinmdaefn-tt:n0opfx ;",
        "marker-type": "llaeb",
        "position": {
            "Width": "",
            "Height": "",
            "X": "",
            "Y": ""
        },
        "point": {
            "x": "842",
            "y": "159"
        },
        "marker-label": "1",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "bmoott"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m a.ryglient-itnoipf:e0dpnxi;  tmoanr gtiunb- b,oytatpo mt:u0ophxt;i wm a,rngyiwnG- lhegfutH: 0rpoxf;  dmeakrrgoiwn -erhi g;httn:a0vprxe;s  -dqetr-ubtlnoecdkn-ii nndae nsta: 0y;l ltaenxitg-iirnod ehnctn:u0Pp xn;h\u0022o>J< stpearnp rsettynlie =o\u0022t  fsonnati-rfoatmsiilhy :d'eLlu csiadha  sGirhaTn d.ee'v;a lfso nat -tsoinz e,:t1n2apvtr;e\u0022s> Ian  stah iost  pdaerrargerfaeprh ,y lsleavceirraolg ekteayc  dseit anihlosJ  etmaehrtg ee.t oFni r,srte,v etwhoeHr e. diesr rau ccnlie asra hs eenhs e\u201d sosfo lt\u201ch ee hlte griosfl aetsinveep mhoiceerra rncih i,esse coifl pcmoolcocnai asli hs odcniae tnyh.o JH ulglhe sG woytn ,d efwroolml aw heob  Jeohh nt aPhutn cdhe tasnedu qtewro  eovtahhe rost  hdaevter orpuenr  aswia yn,y whGa sh gsuuHb m.iftlteesdm iah  phectniutPi onnh otJo  ftoh en ociotuantcniels.e rTph iesh tc osuin ceitlo ni nf ot uorsnl Ah>a\u0022s; tipn2d1i:ceaztiesd- ttnhoaft  ;t'heed ncarriGm ea dnieceudLs' :tyol ibmea fm-atdneo fk n\u0022o=wenl yttos  tnhaep sG<o>v\u0022e;rxnpo0r: tinne dan il-ettxteetr ;; 0t:htenye danrie- kncootl bt-hteq -u l;txipm0a:tteh gaiurt-hnoirgirtaym  i;nx pt0h:et fceoll-onniyg.r<a/ms p;axnp>0<:/mpo>t t<opb -sntiyglrea=m\u0022 -;qxtp-0p:aproatg-rnaipghr-atmy p\u0022e=:eelmypttsy ;p <m a>rpg/i<n>-/t orpb:<0>p\u0022x;;' emdanragriGn -abdoitctuoLm'::0yplxi;m amfa-rtgnionf- l;exfpt0::0tpnxe;d nmia-rtgxient- r;i0g:httn:e0dpnxi;- k-cqotl-b",
        "marker-type": "llaeb",
        "position": {
            "Width": "",
            "Height": "",
            "X": "",
            "Y": ""
        },
        "point": {
            "x": "-66",
            "y": "610"
        },
        "marker-label": "2",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.asregoirng-etno py:a0wpaxn;u rm asrag isnr-ebhottot odmn:a0 phxc;n umPa rnghionJ- lneof tr:a0eplxc;  gmnairegbi ns-irsiaghhptm:e0 pexh;t  -hqtti-wb l,oyctke-iicnodse nlta:i0n;o ltoecx tf-oi nsdtennetm:e0lpex ;l\u0022a>i<csapra ng nsityyllree=d\u0022n uf oenhtt- foatm islay :s'n.oSiFt aNcSi dTneix tr'a;e\u0022l>cH esrnei,a ttnhoec  moesclhaa nhipsamrsg aorfa pc osliohnTi>a\u0022l; 'atuxtehTo rSiNt yF Sa.r'e: yalgiamianf -mtandoef  e\u0022v=iedleyntts.  nIatp sh<a>s\u0022 ;gxrpa0n:ttende dtnhie- tpxoewte r; 0f:otrn ead npia-rktcyo lobf- tmqe-n  ;txop 0b:et hegsitra-bnliigsrhaemd ,; xppa0i:dt fbeyl -pnuibglriacm  f;uxnpd0s:,m ottot ohbu-nnti gdroawmn  ;axnpd0 :rpeocto-vneirg rJaomh n\u0022 =Peulnycths  apn<d  >hpi/s< >a/c crobm<p>l\u0022i;c'etsx.e TA lSsNo ,F So.f' :nyoltiem ahfe-rten oafr e; xtph0e: tdnaetdensi.- tTxheet  e;s0t:atbnleidsnhim-ekncto lobf- ttqh-i s; xcpo0m:mtihsgsiiro-nn ihgarsa mt a;kxepn0 :atrfoeuln-dn i2g5r adma y;sx ps0i:nmcoet ttohbe- npirgervaimo u;sx pp0e:tpiotti-onni gwraasm  s;uybtmpimtet:eedp ytto- htphaer gcaoruanpc-itlq,- \u0022i=nedliyctast ipn<g  >hpo/w< >snlaopws /t<h.es epirtoeciecsosse sl aoifn ogloovce rnnim eenbt  daldumoicn ilsotrrtantoico nd na",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "309",
            "Y": "216"
        },
        "point": {
            "x": "-06",
            "y": "1514"
        },
        "marker-label": "3",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.asrrgaieny- t3o pf:o0 pyxn;o lmoacr geihnt- boott teocmi:v0rpexs;  lmaanrogiitni-dldeaf tn:a0 pdxn;a  mhagrugHi no-tr iegchitv:r0epsx ;s \u2019-rqate-yb lloacnko-iitniddednat :n0a;  ftoe xttn-eimnhdseinntu:p0 pexh;t\u0022 >s<as plalne ws tsyal e,=e\u0022r uftonnetd-nfia mfiol ye:c'i.vSrFe sN Sr iTeehxtt 'f;o\u0022 >tTsheer  ceahptt utrueo  oefv rJeosh no tP udnecchn eatnnde sh iesr af e,lslnoawe pfourguiEt i,vneesm  iess erhetc ofrod ehdt oiBn  .thhsiist tpoacrSa gsria p,hy.r oTgheer Gb rsuetmaalJi t,yr eohft oc oelhotn itasll ishowc i,ehtcyt uiDs  smia d,er octlceiaVr ,, ewniot h; seeaccihl pmmaonc csae nstiehn cdenda  tnoh obJe  ffol osgngiegdi,r or eecheti veirnag  e3t0o n\u201c sftor iopselsA\u201d> \u0022e;a'cthx;e Tw iStNh  FtSh.e' :ryilsikm aoff- tinnoffe c\u0022t=ieolny t\u2013s  nnoatp st<o> \u0022m;exnpt0i:otnn esdhnoic-kt xaentd  ;b0l:otonde dlnois-sk c\u2013o lsbu-cthq -p u;nxips0h:mtehngtisr -wneirger asme v;exrpe0 :atnfde lc-onuilgdr aemv e;nx pb0e: mfoatttaolb.-<n/isgpraanm> <;/xpp>0 :<ppo ts-tnyilger=a\u0022m- q\u0022t=-eplayrtasg rpa<p h>-pt/y<p>e/: ermbp<t>y\u0022;; 'mtaxregTi nS-Nt oFpS:.0'p:xy;l immaarfg-itnn-obfo t;txopm0::0tpnxe;d nmia-rtgxient- l;e0f:tt:n0epdxn;i -mkacroglibn--trqi-g h;tx:p0",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "471",
            "Y": "475"
        },
        "point": {
            "x": "-36",
            "y": "1262"
        },
        "marker-label": "4",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>pp /s<t>ynlaep=s\u0022/ <m.arregtisna-mt ospi:h0 pfxo;  \u2013m aerfgiiln -rbooft t\u2013o my:t0rpexp;o rmpa reghitn -wloenf ts:i0 pexh;  ,mtanragvirne-sr idgehrtu:t0npexd;n i- qnta- brleogcnko-li nodNe n.ts:e0i;n otleoxct -niancdiernetm:A0 phxt;r\u0022o>N< sephatn  nsit yylree=v\u0022a lfso nnta-cfiarmfiAl y,:l'a.gSeFl  NfSo  Teelxptm'a;x\u0022e> Unnwloinkke  thsirsi ff eelhlto ws t\u2013n eEsuerroppeera nh c\u2013n urPu nnahwoaJy s.,t nJeomhunc oPdu nscihh tw afso  seecnntaecnicfeidn gtios  ae umrutc he hwto rssie  sfiahtTe>.\u0022 ;H'et xiesT  oSrNd eFrSe.d' :hyelriem atfo- tsneorfv e\u0022 =heilsy tmsa sntaeprs <f>o\u0022r; xtph0e: trneesdtn io-ft xheits  ;n0a:ttunreadln il-ikfceo.l bM-otrqe-o v;exrp,0 :tthhigsi rp-unniigsrhamme n;tx pi0s: tnfoetl -lniimgirtaemd  ;txop 0V:imrogtitnoiba-,n ibgurta me x;txepn0d:epdo tt-on iegvrearmy w\u0022h=eerley t(sa np <i n>dpi/c<a>t/i ornb <o>f\u0022 ;t'htex eRTo ySaNl  FASu.t'h:oyrliitmya fw-ittnho fw h;ixcph0 :tthneesden ic-otlxoenti a;l0 :ctonuerdtnsi -wkecroel bi-ntvqe-s t;exdp)0.:<t/hsgpiarn->n<i/gpr>a m< p; xspt0y:ltef=e\u0022l--qnti-gpraarma g;rxapp0h:-mtoytpteo:be-mnpitgyr;a mm a;rxgpi0n:-pto",
        "marker-type": "llaeb",
        "position": {
            "Width": "21",
            "Height": "14",
            "X": "306",
            "Y": "784"
        },
        "point": {
            "x": "-75",
            "y": "1294"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "tpo"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};
