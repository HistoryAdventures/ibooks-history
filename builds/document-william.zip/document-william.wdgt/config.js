var widgetconfig = {
    "background_picture": "1gbn4p1.80b080031_b010e023f_9S4_",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "2999",
        "Height": "2110",
        "X": "-159",
        "Y": "-24"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> nsatpysl/e<=.\u0022t nmeanrigmionr-pt oypl:l0apixc;o sm adrngai ny-hbtoltateowm :y0lplxa;c impayrtg ienr-elwe f\u2013t :n0epmx ;l lmaa r\u2013g ilni-crniugohct :e0hptx ;f o- qstr-ebblmoecMk -.iynndoelnotc: 0e;h tt enxit -tirnudoecn tt:s0ephxg;i\u0022h> <eshpta ns as tdyelver=e\u0022s  foosnlta- fyaemhiTl y.:r'oFnarveovroigt 'd;e tfnoinotp-psai zyel:l1a2ypotr; \u0022e>hItn  g1n6i4t0s,i stshae  wVoinr g,innoiiat aGrotvseirnniomrd\u2019as  lCaoiunnocliolc  wfaos  naosikteudt ittos ndie ctindaet roonp mtih en ap udneinsihammeenrt  laipcpnruoopcr ieahtTe  .f4o2r6 1a nn iA fyrniacpamno C\u2013  akinnoiwgnr iaVs  eJhoth no tP unnecvhi g-  dwahho  Ih asde maatJt egmnpitKe dr ettor arhucn aewhaty  ftoo  nMoairtyullaonsds.i dT heehitr  gvneirwdoilclto fo n, ytnhoel ocCa snew,o rsCh oaw ne mionc etbh ed adho cauimneingtr ibVe lso\u2019w0,4 6w1o uelhdt  hnaIv>e\u0022 ;ptrpo2f1o:uenzdi si-mtpnaocft  ;o'nt itrhoev arFe'l:aytliiomnasfh-itpn obfe t\u0022w=eeelny tEsu rnoappes,< >A\u0022f;rxipc0a: tannedd ntih-et xAemte r;i0c:atsn.e d<n/is-pkacno>l<b/-stpqa-n >; x<pp0 :stthyglier=-\u0022n imgarragmi n;-xtpo0p::t0fpexl;- nmiagrrgaimn -;bxopt0t:om",
        "marker-type": "llaeb",
        "position": {
            "Width": "",
            "Height": "",
            "X": "",
            "Y": ""
        },
        "point": {
            "x": "677",
            "y": "146"
        },
        "marker-label": "1",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "bmoott"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> nsatpysl/e<= \u0022. ymlaertgiinni-fteodpn:i0 ptxo;n  mtaurbg i,ny-abpo tttuoomh:t0ipwx ;, nmyawrGg ihng-ulHe frto:f0 pdxe;k rmoawr geihn -;rtingahvtr:e0sp xd;e r-uqttn-ebdlnoic kn-ai nsdae nytl:l0a;n itgeixrto- ihncdneunPt :n0hpoxJ; \u0022t>e<rsppraent nsit yolte =s\u0022n afiornott-sfiahm idleyl: 'sFaahv osriihtT' ;. efvoanlts- sai zteo:n1 2,pttn;a\u0022v>rIens  tah issa  poatr adgerrarpehf,e rs eyvlelraacli rkoegye tdaect asiil sn heomJe rtgaeh.t  Feitrosnt ,, rtehveerweo Hi s. dae rcrluecanri  sseanhs ee ho f\u201d stshoel \u201cl eeghits lraotfi vees nheipemroacrecrh ineis  ,osfe cciollpomnoicacla  ssoichi edtnya.  nHhuogJh  lGlweysn ,o tf rdoemw owlhloa  Jeobh ne hP utnachht  adnedt stewuoq eort heevrash  hoatv ed erturno paewra ys,i  hnaysw Gs uhbgmuiHt t.efdl eas mpieht ihtcinounP  tnoh otJh ef oc onuonictialt.n eTsheirsp  ceohutn csiil  eitno nt ufron  ohsalsA >i\u0022n;dtipc2a1t:eedz itsh-attn otfh e; 'ctriirmoev anFe'e:dysl itmoa fb-et nmoafd e\u0022 =kenloywtns  tnoa ptsh<e> \u0022G;oxvpe0r:ntonre dinni -at xleett t;e0r:;t ntehdenyi -akrceo lnbo-tt qt-h e; xupl0t:itmhagtier -anuitghroarmi t;yx pi0n: ttfheel -cnoilgornaym. <;/xspp0a:nm>o<t/tsopba-nn>i g<rpa ms t;yxlpe0=:\u0022p omta-rngi",
        "marker-type": "llaeb",
        "position": {
            "Width": "",
            "Height": "",
            "X": "",
            "Y": ""
        },
        "point": {
            "x": "-117",
            "y": "603"
        },
        "marker-label": "2",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. ssetoyrlgee=n\u0022  ymaawragniunr- tsoap :s0rpexh;t om adrngai nh-cbnoutPt onmh:o0Jp xn;o  mraareglicn -glneifetb: 0spixs;a hmpamreg ienh-tr ihgthitw: 0,pyxt;e i-cqots- bllaoicnko-lioncd efnot :s0t;n etmeexlte- ilnadiecnatr: 0gpnxi;y\u0022l>rHeedrneu,  ethhte  omte cshaa nsinsomist aocfi dcnoil ornaieallc  asuntihaotrniotcy  oasrlea  ahgpaairng amraadpe  seivhiTd>e\u0022n;tx.p 0I:tt nheadsn ig-rtaxnette d; 0t:hten epdonwie-rk cfoolrb -at qp-a r;txyp 0o:ft hmgeinr -tnoi gbrea me s;txapb0l:itsfheeld-,n ipgariadm  b;yx pp0u:bmloitct ofbu-nndisg,r atmo  ;hxupn0t: pdootw-nn iagnrda mr e\u0022c=oevleyrt sJ oph<n  >Pnuanpcsh/ <a.nsde ihtiesi caocsc olmapilniocleosc.  nAil seob,  dolfu onco tleo rhtenroec  adrnea  tnhoei tdaarttessi.n iTmhdea  etsnteambnlriesvhomge nfto  osfe stsheicso rcpo memhits swioolns  hwaosh  tgankietna cairdonuin d, l2i5c nduaoycs  eshitn coet  tdheet tpirmebvuiso ussa wp entoiit",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "309",
            "Y": "216"
        },
        "point": {
            "x": "-117",
            "y": "1714"
        },
        "marker-label": "3",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. ssrtayelye =3\u0022  fmoa rygnionl-otco pe:h0tp xo;t  meacrigvirne-sb oltatnoomi:t0ipdxd;a  mnaar gdinna- lhegfutH: 0optx ;e cmiavrrgeisn -sr\u2019irgahety: 0lpaxn;o i-tqitd-dbal oncak -fion dtennetm:h0s;i ntuepx te-hitn dsean tl:l0epwx ;s\u0022a> T,heer uctanpetdunrie  foof  eJcoihvnr ePsu nrcihe hatn df oh itss efre lelhotw  tfuuog ietvirveess  oits  dreeccnoertdneeds  ienr at h,issn apeaproargurEa p,hn.e mT hees ebhrtu tfaol ihttyo Bo f. hcsoiltotnoicaSl  ssio c,iyertoyg eirsG  msaedmea Jc l,eraerh,t ow iethht  etasclhi hmwa n, hscetnutDe nscie d, rtoot cbieV  f,leongog e;ds,e crielcpemiovcicnag  s3i0h  \u201cdsntar inpheosJ\u201d  feoa cshn;i gwiirtoh  ethhte  errias ke toofn  ifnof eocstliAo>n\u0022 ;\u2013x pn0o:tt nteod nmie-nttxieotn  ;s0h:otcnke dannid- kbcloolobd- tlqo-s s; x\u2013p 0s:utchhg ipru-nniisghrmaemn t;sx pw0e:rtef esle-vneirger aamn d; xcpo0u:lmdo tetvoebn- nbieg rfaamt a;lx.p<0/:sppoatn->n i<gpr asmt y\u0022l=e",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "471",
            "Y": "475"
        },
        "point": {
            "x": "-117",
            "y": "1452"
        },
        "marker-label": "4",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. rsettyslaem= \u0022s imha rfgoi n\u2013- teofpi:l0 prxo;f  m\u2013a rygtirne-pboortpt oemh:t0 pwxo;n  msair geihn -,ltenfatv:r0epsx ;d emraurtgniend-nrii gnhat :r0epgxn;o l- qotN- b.lsoecikn-oilnodce nnta:c0i;r etmeAx th-tirnodNe neth:t0 pnxi; \u0022y>rUenvlailkse  nhaicsi rffeAl l,olwa g\u2013e lE ufroo peelapnm a\u2013x er unnwaownaky st,s rJiofh ne hPtu nscthn ewsaesr pseern thecnncuePd  nthoo Ja  .mtuncehm uwcoords es ifhatt ef.o  Heec niasc iofridnegriesd  ehuerrte  ethot  sseir vsei hhTi>s\u0022 ;mxaps0t:etrn efdonri -tthxee tr e;s0t: tonfe dhniis- kncaotlubr-atlq -l i;fxep.0 :Mtohrgeiorv-enri,g rtahmi s; xppu0n:itsfhemle-nnti girsa mn o;tx pl0i:mmiottetdo bt-on iVgirragmi n;ixap,0 :bpuott -enxitgernadme d\u0022 =teol yetvse rpy<w h>enraep s(/a<n  .i)nddeitcsaetvinoin  eorfe wt hset rRuooyca ll aAiuntohloorci teys ewhitt hh cwih",
        "marker-type": "llaeb",
        "position": {
            "Width": "21",
            "Height": "14",
            "X": "306",
            "Y": "784"
        },
        "point": {
            "x": "-117",
            "y": "1486"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a1c_4_60003bdc3",
        "popup-location-preference": "tpo"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};