var widgetconfig = {
    "background_picture": "8g4ndp5.b85667f_1342b65_1Se_00",
    "resize-policy": "Iemlabgaee zdirsaegrg adbnlae ",
    "position": {
        "Width": "4300",
        "Height": "6400",
        "X": "-51",
        "Y": "-52"
    },
    "hotspots": [{
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. rsettytleel= \u0022s \u2019mnairLg idne-ttpompo:r0pp xt;a hmta rsgpiinh-sbnootittoaml:e0rp xf;o  mnawrogdikna-elrebf te:h0tp xo;t  mdaerlg imnu-irpiog hfto: 0eplxa;s  -eqhtt- bdlnoucokr-ai nsdneonits:n0e;t  tgenxits-iirn deernotf:e0bp xs;e\u0022i>r\u201cuIttn eics  lmaerreevleys  frroofm  ytrhtensueo cc ierhctu mfsot aynccielso,p  tah ante eybo udra hc oaunnithrCy -h-t-idwe reidvairntg  niim mtesnesree tandiv ahnstiatgier Bf reohmt  ittash tc oemrmeehr ceieasl  nianct eerWc>o\u0022u;rxspe0 :wtintehd nuis-,t xwehti c;h0 :htanse dennid-ukrceodl bn-otwq -t w;ox ph0u:ntdhrgeidr -yneiagrrsa-m- -;hxaps0 :btefceolm-en itghrea mr i;cxhp 0a:nmdo tftloobu-rniisghrianmg  ;kxipn0g:dpoomt -tnhiagtr aimt  \u0022i=se lsyatisd  pt<o  >bpe/!<\u201d><// srpba<n>>\u0022 ;<xpp 0s:ttynleed=n\u0022i--qttx-epta r;a0g:rtanpehd-ntiy-pkec:oelmbp-ttyq;-  m;axrpg0i:nt-htgoipr:-0npixg;r amma r;gxipn0-:btoftetlo-mn:i0gprxa;m ",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "-77",
            "Y": "365"
        },
        "point": {
            "x": "-5",
            "y": "3720"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>t\u201cpbmye :meepaynts- hopfa rignatrraopd-utcqi-n\u0022g= eolpyitusm  pb<y  >spt/e<a lmteht,s yhsa vneo tsneadCu ceehdt  ogunri sCshaipn-eysbe  epreeowp lset,n aahncdr ecma uesheTd  .e\u201dvhetrlya eptrso\u201cv ihngcueo rohft  tahnei hlCa nodt ntio  gouvredr felhotw  gwniitlhg gtuhmast  fpoo isstonna\u201dh<c/rsepma nh>s i<tpi rsBt yelhet= \u0022s emsaurcgcian -ytloepv:i0tpcxe;f fmea rogsilna- beoht ttoamh:t0 pext;o Nm a.rggniinl-lleetf te:t0ipuxq;  smia rngoisni-orpi gshat :t0ip xf;o  -nqoti-tbalsoicrke-ticnadreanhtc: 0s;i ht e;xytt-eiincdoesn te:s0epnxi;h\u0022C> Lnion \u2019tsc elfeftet eerv imtaadree ncelgeeadr  ytlod nVuiocftoorrpi aa,  gtnhiev aQhu eseanw  asnddn aElm perseesnsi,h Ct hoattn it hmeu iipnot rfood uncoti",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "539",
            "Y": "26"
        },
        "point": {
            "x": "612",
            "y": "45"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "ltef"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n. hsttayelde =o\u0022t  mdaerngmiend-ntoocp :e0bp xd;l umoawr ghitno-bb o:tetloams: 0dpnxa;  emsaur gsignu-rlde feth:t0 pfxo;  ymtalriguign -drniugohft :e0rpexw;  o-hqwt -ebsloohctk -oitn dteunot :d0e;t etme xttn-eimnhdseinntu:p0 pexh;t\u0022 >n\u201ciE vdeertya cniadtniiv es io fe stehnei hICn neehrt  Lyabn de bw hoot  sdeelvlise corpeipu ms,a wa st ia lssao  maelllb owrhpo  eshmto kfeo  iytt,i raervee sa leihkte  ,andijaugdAg>e\u0022d; xtpo0 :dtenaetdhn\u201di<-/tsxpeatn >; 0<:pt nsetdynlie-=k\u0022c omlabr-gtiqn-- t;oxpp:00:ptxh;g imra-rngiignr-abmo t;txopm0::0tpfxe;l -mnairg",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "-77",
            "Y": "405"
        },
        "point": {
            "x": "-50",
            "y": "521"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }, {
        "Type": "TpeuxptoP",
        "text": "<>spp/a<n> /s trybl<e>=\u0022\u0022; xmpa0r:gtinne-dtnoip-:t0xpext;  ;m0a:rtgniend-nbio-tktcooml:b0-ptxq;-  m;axrpg0i:nt-hlgeifrt-:n0ipgxr;a mm a;rxgpi0n:-trfieglh-tn:i0gprxa;m  -;qxtp-0b:lmooctkt-oibn-dneingtr:a0m;  ;txepx0t:-piontd-ennitg:r0apmx ;;\u0022y>t\u201cpYmoeu:re phyotn-ohrpaabrlgea rnaapt-itoqn- \u0022t=aekleyst sa wpa<y  >tph/e< .perpoodruucEt sf oo fs toeukrr acme nethrta ln il atnsde,r eatnndi  nloutf iotnnleyl pd od eytocua rtthtear esbdyn aolb tcaiitno xfeo omdo rafn ds dsouopgp orrotf  fdonra myeodu reshetl vdensa,  ,beusti rmporreetonvee rl,a ibrye prmei- seehltl ifnog  gtnhieks ee hptr osdauwc ttsi ftoor Po t.hmesri lcaoiurnetprmiie sc iymooun orceea pn aae ptohrrueEe ffool dl aporgo fliatr.t\u201dn<e/cs peahnt>  s<eps ssetryplxee= \u0022n imLa r,geirne-Ht>o\u0022p;:x0pp0x:;t nmeadrngii-nt-xbeott t;o0m::t0npexd;n im-akrcgoilnb--lteqf-t :;0xppx0;: tmhagrigri-n",
        "marker-type": "llaeb",
        "position": {
            "Width": "100",
            "Height": "40",
            "X": "-57",
            "Y": "440"
        },
        "point": {
            "x": "-7",
            "y": "348"
        },
        "marker-label": "",
        "marker-image": "9g1n0pb.a0c04b6c033d",
        "popup-location-preference": "rtihg"
    }],
    "support_student_account": "no",
    "student_account_school": {
        "name": "Aennyo",
        "code": ""
    },
    "student_account_authrestrict": "yse",
    "widget_language": "",
    "LocalizationMap": {
        "Hotspot accesses": "",
        "Hotspots accessed": ""
    },
    "cover": "Dgenfpa.utl",
    "widget_orientation": "Vlearcti",
    "WA": "\u005cgC0bhKllQ5MaOLbBXMZ?X4BOE:J9",
    "student_account_server": "h1tvt/pisp:a///maopci..sbtoeogkdwi",
    "kmuserid": "6846578804981081",
    "sec": "{}"
};
